# Full Kit Composed — GPT Sol, Round 3

September 18, 2026 · response to Grok Round 2 · architecture/build contracts, not an application release

**Decision:** build the useful, complete local office as the primary deployable. Add the hub when shared authority or actual outside execution requires it. Slice 1 is the local foundation, not a claim that every composed office function ships in its first increment. No hub, identity vendor, model service, or radio is required to capture, bind, record, prepare, and back up.

Grok's attached file is a proposal being adjudicated under Glen's request. Its retained laws and changes are incorporated below with explicit qualifications. Historical application 0.2.0 remains unchanged; this round generates contracts and a coding plan, not a new runnable field application.

## 1. Accept/reject and experiment disposition

| ID | Decision | Round 3 integration |
|---|---|---|
| C1 | Accept | Local domain/edge/Qt/SQLite/blobs are the primary product foundation. An unlocked authorized local session continues offline. A shared hub owns shared commitments when activated; it cannot become a prerequisite for ordinary capture or preparation. Slice 1 covers specified foundation functions, not a premature all-functions claim. |
| C2 | Accept | PySide6 desktop owns Today, dossier, capture, and documents. Later supported-browser call widget owns audio only. No Tauri redesign or second Today. |
| C3 | Accept | Managed OIDC is the shared-pilot default. Vendor remains open pending actual account/recovery tests. No Keycloak in Slice 1 or the default $24 hub estimate. Local single-owner trust is not OIDC and is not sold as technician authentication. |
| C4 | Accept with scope correction | Enforce Home on every local repository/command/blob/document/backup path in Slice 1. PostgreSQL and RLS belong to the hub before any real shared user/data is admitted. The two local Homes in Slice 1 do not require PostgreSQL/RLS. A second human using the application requires authenticated scoped accounts; that remains out of Slice 1. |
| C5 | Accept | Prove actual inbound/outbound laptop calls and provider fallback before conversational secretary. Use DTMF “press 0” initially; “say Glen” introduces speech processing and its own permission/configuration/cost qualification. No Relay in the first call path. |
| C6 | Accept | Local language plus speech/OCR capabilities; no second reasoning model or GPU. Slice 1 ships with AI off/optional, not with an untested transcription button. Capture and calls take precedence over inference. |
| C7 | Accept subject to measured spike | Freeze the 20 local RPC methods below. Two-day QProcess versus in-process writer-queue spike uses the same application API and failure semantics. Select using evidence before feature generation expands the protocol. |
| C8 | Accept | No ROBOT_ACTUATION token, dummy robot adapter, or robot capability checkbox in shipped files. Future extensibility remains in the adapter contract; robots remain halo. |
| U1 | Accept experiment; not run here | On Glen's exact Windows/WWAN kit: inbound/outbound call while evidence capture and actual console work continue, then sleep/resume/fallback. Record hardware/carrier/audio/latency/power and missing provider setup. Not evidence we currently possess. |
| U2 | Accept; revise comparison | Test managed OIDC owner/tech enrollment, MFA recovery, device-session revocation, provider outage, and backup-operator recovery. Compare Keycloak on 8 GiB only if managed identity fails a substantive requirement. Fifteen minutes is a proposed recovery target, not established performance. |
| U3 | Accept and make objective | Exercise 100 photo attachments, 20 command submissions, UI resize, restart, and lost-response lookup. Select QProcess if framing, responsiveness, recovery, and packaging pass. Same API survives an in-process fallback. |
| U4 | Accept; pending Glen's account choice | Reserve one later business adapter slot. Do not invent mailbox credentials or scaffold ten providers. Selecting the mailbox is not required to complete Slice 1. |

**Capture law, precisely:** hub outage, expired remote grant, or unavailable identity provider must not prevent raw local intake in an already-unlocked authorized session. Missing job context goes to that Home's unassigned inbox. Capture is not permission to execute field changes. A locked Windows session, unknown local owner, disk failure/full disk, or another Home's access boundary is not bypassed. No anonymous dossier access or secretly unencrypted emergency inbox.

## 2. Slice-1 trust, storage, and module boundary

One trusted owner on one enrolled Windows profile, with two explicitly provisioned Homes. Both may be accessible to that owner, but only the selected Home is active for a request. Switching Home is explicit; pending capture stays with its original Home. A request naming Home B while Home A is active fails before object lookup and reveals no B revision, filename, title, or result. This is context isolation, not a claim that the same entitled owner can never switch businesses or that a hostile local administrator cannot inspect their disk.

Use a separate local store directory and SQLite database per Home; a minimal owner index lists authorized Home IDs and locations, without dossier content. Composite Home-scoped references remain in each database so imported and future shared data cannot omit Home accidentally. Blob paths and opaque file tokens belong to a Home. Never use one global cross-Home content-addressed blob directory. Windows-protected storage/encrypted volume must be commissioned before real sensitive data; encryption/recovery status is a readiness item, not a fictional function.

| Module | Public functions to generate | Required first tests |
|---|---|---|
| domain/types, policy, tracks | validate_command, check_local_context, check_revision, apply_scope_change, validate_track_transition | Unknown fields/types rejected; foreign Home blocked; stale revision; scope change invalidates affected local authority; sourced manual status cannot be presented as automated delivery/payment. |
| application/commands | execute_command, get_operation_receipt, canonical_command_digest | Same operation/same payload returns same receipt; changed payload or Home under same ID fails; lost response then lookup produces one mutation. No arbitrary caller principal. |
| adapters/sqlite | open_supported_store, transaction, append_event, persist_receipt, scoped_query | WAL/FULL/foreign keys/runtime gate; rollback; acknowledged commit survives core termination; queries always require context. |
| adapters/fs_blobs | stage_file, publish_blob, verify_blob, reconcile_staging | Bad token/path/symlink, wrong digest/length, cross-Home token, failed flush/publish, orphan blob and missing referenced blob; no metadata-before-publication. |
| domain/identity | observe_identity, assign_observation, verify_bind, dispute_bind, recall_bind | Typed/photo-source observation; assignment once; expected head 0→1; correction 1→2; wrong job; disputed recall; asset_label not returned as serial; source file integrity. |
| application/documents | prepare_document, resolve_identity_snapshots | Immutable original and correction snapshots; disputed/unresolved serial blocks pinning; customer view excludes private records; prepared never means sent. |
| domain/local_office | record_time, record_cost, move_stock, put_reservation | Time ordering; USD minor units; nonnegative usable stock; legacy integer-unit arithmetic; protected hard-envelope conflict; no required cloud/time estimate. |
| application/interruption | record_interruption | Exposed/reversible/irreversible/unknown state retained; secured-on-hold requires stabilization result/evidence or explicit sourced human account; no physical automation or invented emergency authority. |
| application/recovery | create_home_backup, verify_backup, restore_inactive | Consistent DB/blob manifest; incomplete bundle fails; wrong Home access denied; restored copy is inactive; legacy pending actions cannot execute. |
| migrations/local | inspect_legacy, plan_import, import_legacy, reconcile_import | Source byte-for-byte unchanged; ID mapping/count/digest checks; claimed names stay claimed; unknown legacy content retained with warning; no pending-action replay. |
| edge/rpc and desktop | dispatch_rpc, select_home, build_today, refresh_job, capture_to_inbox | Raw RPC bypass attempts, context switch during attachment, restart/reconnect, UI-only controls insufficient, no unavailable feature reports success. |
| application/readiness | get_readiness | Backup age/integrity, active Home, storage/encryption checks, missing asset bind, unresolved operations, battery/WWAN observations; unknown stays unknown. |

Home bootstrap and legacy import run through owner-only maintenance entry points while the target Home's normal writer is stopped. Restore writes only a new inactive destination. No hidden database writes from the GUI, adapters, model workers, or maintenance tools running concurrently with the core.

## 3. Frozen local interface: 20 methods, version v0

QProcess carries JSON-RPC 2.0 newline frames, UTF-8; stdout protocol only; stderr diagnostics; 1 MiB frame limit. File content goes through Home-bound opaque staging tokens, not JSON bytes or arbitrary caller paths. In-process fallback exposes identical typed application calls and command receipts; it does not weaken single-writer ownership.

| # | Method | Contract / result |
|---|---|---|
| 1 | home.list | No Home parameter; authorized owner index only. |
| 2 | session.select_home | Select an authorized Home; increment session context generation; invalidate old pending UI work. |
| 3 | job.create | cmd.v0; caller-generated new job UUID; revision 0→1; scope starts at 1. |
| 4 | job.list | Active Home; bounded cursor/limit; summaries only. |
| 5 | job.get | Active Home + job UUID, or null for the unassigned inbox; bounded scoped dossier/inbox views. No all-jobs wildcard. |
| 6 | job.update | cmd.v0; typed scope or track update; expected job aggregate revision. |
| 7 | record.add | cmd.v0; typed note/time/cost/legacy-compatible stock movement; job or Home inbox. |
| 8 | evidence.attach | cmd.v0 + evidence.v0 attach input; available evidence or failure. |
| 9 | serial.observe | cmd.v0 + bind.v0 observe input; new unassigned observation. |
| 10 | serial.assign | cmd.v0 + bind.v0 assign input; assignment expected 0, stored 1. |
| 11 | serial.verify | cmd.v0 + bind.v0 verify input; expected current asset bind revision. |
| 12 | serial.recall | Active Home + job/asset UUIDs + optional historical revision; verified/unresolved result. |
| 13 | serial.dispute | cmd.v0 + bind.v0 dispute input; expected bind revision; head disputed without rewriting bind. |
| 14 | document.prepare | cmd.v0; work_order/job_summary/closeout; immutable prepared artifact. |
| 15 | interruption.record | cmd.v0; sourced interruption only; no physical actions. |
| 16 | reservation.put | cmd.v0; local envelope/resource reservation, expected reservation revision. |
| 17 | operation.get | Active Home + operation UUID; scoped durable receipt, not a retry. |
| 18 | backup.create | cmd.v0; Home-scoped archive into owner-approved destination token. |
| 19 | backup.restore | cmd.v0; archive/destination tokens; inactive mode only. |
| 20 | system.status | Protocol/runtime, readiness, operation/storage health; no unrelated Home data. |

Queries are side-effect-free, except session.select_home changes ephemeral context. Query parameters reject unknown fields; pagination is bounded to 100 items. Local session context is core-owned, derived from the trusted Windows owner; JSON-supplied principal names do not establish authority. Detailed view DTOs remain implementation details of Slice 1, not six additional durable contracts.

Opaque staging/destination tokens are created by the trusted local intake/maintenance component, bound to Home, session generation, and canonical vetted paths. The native intake helper writes a token manifest and staged file under that Home's ACL-protected staging root; the core verifies the manifest, current session generation, file type, and canonical root before publication. This uses the same trusted Windows owner as the rest of Slice 1; it is not a security promise against that owner forging local files. Destination tokens come from owner-approved maintenance configuration, not pasted arbitrary paths. QProcess does not accept arbitrary filesystem paths from pasted RPC. Bind token resolution to operation ID before a consequential attempt so a lost response does not make its result unrecoverable. A future LAN or companion client is out of scope.

## 4. Three frozen contracts

Machine-readable draft-2020-12 files accompany this document: cmd.v0.json, bind.v0.json, evidence.v0.json. Each rejects unknown properties and validates UUIDs and offset-aware timestamps. The IDs use a reserved documentation namespace; they do not name a provisioned internet service. Examples are specification specimens, not actual observations or receipts. Formal files govern structural validation; the invariants below govern domain/file validation. JSON Schema alone cannot establish permissions, file durability, label truth, or operation success.

### cmd.v0 — command and durable receipt

Command fields: schema, kind, operation_id, home_id, command, job_id, job_scope_revision, expected_revision, payload. All fields are present; nullable fields are explicit null. Allowed commands are exactly the 13 mutating RPC methods above. Each has a strict typed payload. No caller actor, provider success flag, free-form executable command, or additional property is accepted.

Creation expects revision 0. Job updates compare job aggregate revision, serial assignment compares assignment revision, serial verify/dispute compare current asset bind revision, reservations compare reservation revision. Append-only commands use expected_revision null. Job-affecting transitions name the cached current scope revision; raw evidence capture is allowed regardless of scope drift. record.add uses null job/scope for the Home inbox, or the named job/current scope; this permits plain-text capture before a job exists. Unassigned observation/backup commands have null job/scope. Validation and revision checks occur in the same transaction as the mutation and receipt.

Receipt fields: schema, kind, operation_id, home_id, command, state, expected_revision_seen, new_revision, result_ref, error, recorded_at. States are queued/executing/confirmed/failed/unknown. Confirmed means the named local result is durable, not externally issued. Rejected valid-domain commands use failed plus a stable error code; malformed or unauthorized requests receive a JSON-RPC error without leaking a foreign receipt/revision. expected_revision_seen is the current authorized target revision checked; it is null for append operations. new_revision is null when the target has no revision or business mutation failed.

```json
{
  "schema": "cmd.v0", "kind": "command",
  "operation_id": "77777777-7777-4777-8777-777777777777",
  "home_id": "11111111-1111-4111-8111-111111111111",
  "command": "serial.verify",
  "job_id": "22222222-2222-4222-8222-222222222222",
  "job_scope_revision": 1, "expected_revision": 0,
  "payload": {
    "observation_id": "44444444-4444-4444-8444-444444444444",
    "asset_id": "33333333-3333-4333-8333-333333333333",
    "verification": {
      "method": "physical_label_review",
      "description": "Owner compares actual label with original photo",
      "evidence_ids": ["66666666-6666-4666-8666-666666666666"],
      "claimed_verifier": "Glen"
    },
    "reason": "First verified bind"
  }
}
```

The corresponding confirmed receipt has the same operation/Home/command, expected_revision_seen 0, new_revision 1, result_ref equal to the generated bind UUID, error null, and a core-generated recorded_at. A response lost after commit is retrieved by operation.get using the original UUID. Payload digest includes schema, command, Home, job, scope, revision expectation, and payload. Reusing an operation ID with different content is OPERATION_ID_CONFLICT. Core resolves identity from its session and applies the current policy before looking up receipts; switching Home cannot expose another Home's receipt.

Schema reject examples: extra actor; negative revision; null scope for serial.verify; unknown command; unknown nested payload key. Domain rejects: stale bind head/scope; cross-Home observation/token; reused observation; different payload under same operation ID; unavailable referenced evidence.

### bind.v0 — observation, assignment, verified bind, dispute

Four separate immutable facts, not one giant mutable identity object. Home and generated identifiers are mandatory on each stored fact. principal_ref is core-generated attribution: Windows local owner for new records, explicit legacy claimed provenance for imports. Claimed observer/verifier text remains distinct.

Observation contains raw_value (nonempty text or null), serial/asset_label kind, trim_only.v0 normalization, nullable manufacturer/model, source kind/description/evidence IDs/observed time, captured time, and principal reference. Photo capture means a real imported/captured image plus owner-entered transcription; it does not claim OCR. Unknown text is null. Case, leading zeroes, punctuation, and internal whitespace are preserved.

Assignment binds the observation once to job/asset within Home, stored revision 1. An owner explicitly supplies a new asset UUID at assignment when no asset exists; the transaction creates that scoped asset record. No inferred merge creates or aliases assets. Verified bind references that assignment, exact verification source, job/asset, head revision, predecessor, reason, and verification time. Asset bind head key is (Home, asset); revision zero means no verified bind, first stored bind is one. Correction uses a new observation and expected current head; it appends a successor. Dispute records the challenged bind/head revision and changes head availability without changing the historical bind or incrementing its immutable bind revision.

```json
{
  "schema": "bind.v0", "kind": "verified_bind",
  "home_id": "11111111-1111-4111-8111-111111111111",
  "bind_id": "55555555-5555-4555-8555-555555555555",
  "observation_id": "44444444-4444-4444-8444-444444444444",
  "job_id": "22222222-2222-4222-8222-222222222222",
  "asset_id": "33333333-3333-4333-8333-333333333333",
  "revision": 1, "predecessor_bind_id": null,
  "identity_kind": "serial", "normalized_value": "SN-001",
  "verification": {
    "method": "physical_label_review", "description": "Physical label checked",
    "evidence_ids": ["66666666-6666-4666-8666-666666666666"],
    "claimed_verifier": "Glen"
  },
  "verified_at": "2026-09-18T14:00:00Z",
  "principal_ref": "windows-local-owner", "reason": "Initial verification"
}
```

Recall returns verified serial only when the selected Home/job has an explicit verified association with the asset and the active head is valid. Wrong-job/missing/disputed/asset_label cases return unresolved with serial null; a foreign Home fails authorization without revealing existence. Historical recall names revision and reports current dispute separately. It is never used automatically for current document preparation. Documents pin exact bind ID/revision/value; no caller-supplied identity snapshots.

Schema rejects: revision zero stored bind; predecessor on revision one; missing predecessor on successor; observation carrying a verified flag. Domain rejects: assign twice; verify same observation twice; normalized value inconsistent with raw source; silent asset merge; photo source without valid Home-scoped evidence; disputed/unresolved serial pin; stale head/dispute race. No OCR confidence threshold creates a bind.

### evidence.v0 — durable original and metadata

Attach input includes stage_token, declared digest/length, original_name, media_type, origin, nullable observed_at, source_description, and classification. Core reads and hashes the actual staged file; client declarations are expectations, not proof. Stage tokens are Home-bound. A photo import has observed_at null when the capture time is unknown.

Available evidence includes Home, nullable job, evidence ID, blob key, digest/length, original filename/media type/origin, source time/description/classification, publication time, and principal reference. Blob key is sha256/<digest> within the Home's root; it is not a caller-controlled path. Originals are immutable; annotations/extractions do not replace them.

```json
{
  "schema": "evidence.v0", "kind": "available_evidence",
  "home_id": "11111111-1111-4111-8111-111111111111",
  "job_id": "22222222-2222-4222-8222-222222222222",
  "evidence_id": "66666666-6666-4666-8666-666666666666",
  "blob_key": "sha256/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  "sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  "byte_length": 1234, "original_name": "label.jpg", "media_type": "image/jpeg",
  "origin": "file_import", "observed_at": null,
  "source_description": "Specification example; not a verified real file",
  "classification": "ordinary_job", "published_at": "2026-09-18T14:00:00Z",
  "principal_ref": "windows-local-owner"
}
```

Publish order: approved staging → actual hash/length/media checks → flush and same-volume atomic publication → metadata/event/receipt transaction. Home checks happen before staging lookup. Failed metadata leaves a recoverable orphan; missing original is integrity failure, not available evidence. Cancel before commit may abandon staging; cancel after commit cannot undo an acknowledged command. Windows storage/power assumptions require later qualification.

Schema rejects: invalid digest, zero/oversized length, traversal blob key, extra property. Domain rejects: digest/key mismatch; declared bytes differ; MIME mismatch under declared policy; symlink/root escape; cross-Home stage token; missing original; filename used as storage path; metadata committed before publication. The hash specimen above does not establish that any such real file exists.

## 5. Tests to write before feature generation

1. Raw core/RPC tests for Home mismatch on jobs, observations, evidence tokens, documents, operation receipts, backup and restore. Repeat with the same business data IDs intentionally present in both separate stores. Switching sessions during queued work must not redirect it.
2. Command transaction/idempotency tests: before-commit crash, after-commit-before-response crash, stale revisions, payload conflict, duplicate operation lookup, failed command rollback, and durable receipt.
3. Blob recovery tests at each publish boundary; file integrity and snapshot tests; no available metadata for missing original.
4. Serial lifecycle: unassigned typed/photo observation, single assignment/verification, expected 0→1→2, dispute, wrong job, label-only identity, historical prepared document unchanged. Port relevant legacy behavior tests rather than assuming they cover new Home/session logic.
5. Local office tests: time/cost/stock conservation; reservation envelope including prep/travel/documentation/recovery; separate tracks and actual contract/manual provenance; scope change interruption record without physical automation.
6. Backup/import tests: source immutability, consistent manifest, inactive restore, claimed attribution, migration reconciliation and ambiguous legacy warnings. Never execute legacy pending actions.
7. Actual Qt smoke/spike: Today/Job/Capture/Exceptions, explicit Home switch, 100 photos and resizing, core restart and operation lookup; supported Windows runtime and commissioning report. Every enabled button must have a real handler. AI/voice/cloud/pack writes have no misleading enabled controls.

These are tests to generate in Round 5, not tests run against a finished Slice 1 today. This round validates the formal schemas/examples only. A schema pass is not a hardware, GUI, power-loss, or commercial qualification.

## 6. Departure readiness and power: CAP71 and CAP72

**CAP71 Departure readiness — horizon:** Today shows active Home/job, missing verified asset binds, scoped local authority/source, outstanding interruption, tool list, optional pack applicability, backup age/integrity, encrypted-storage commissioning, free disk, battery observations, WWAN observation, and unresolved operation receipts. Slice 1 cannot invent remote grant, pack, call, or cloud readiness; show not-installed/not-applicable/unknown honestly. Readiness explains blockers but must not block raw capture. Departure override is a sourced owner decision, not a way to override a critical procedure gate.

**CAP72 Power/thermal budget — horizon:** software reports observed OS battery state and whether the optional heavy worker is active, pauses/caps optional inference under an explicit owner policy, and records unknown sensor data. Exact battery thresholds and thermal sensors are selected after the SKU trial. Actual runtime measurement covers capture+console, then WWAN+call, then optional inference. No all-day or seamless hot-swap promise before evidence. Slice 1 contributes status and workload controls; later phone qualification contributes radio/audio evidence.

Other deltas only: CAP42 stays halo and absent from shipped registry; CAP58 first path is real browser calls/fallback; CAP59 secretary waits for CAP58; CAP62 model adapter historical, optional/off; CAP67 Slice 1 is local context isolation, Slice 2 real authenticated sharing/RLS. No capability moves to floor because this contract exists.

## 7. Explicitly out of Slice 1

apps/hub; apps/worker cloud outbox executor; apps/voice-console; managed OIDC implementation; Keycloak; PostgreSQL/RLS deployment; sync/offline signed grants; opaque cross-Home server busy sharing; real outbound messages; provider webhooks; marketplace execution; invoice issuance/payment automation; cloud AI gateway; automatic speech/OCR; validated guided installation; platform pack write plans; ConversationRelay; robotics; guided fiber/splicing; custom carrier.

There is no pretending that Slice 1 is phone-ready: it is the useful local foundation of the phone-ready product. Commission real calls in the later call slice or a separately bounded parallel hardware qualification, without adding unfinished voice controls to Slice 1. Local document preparation, scoped records, interruption record, legacy-compatible time/stock/cost, reservations, backups, and import remain in Slice 1.

## 8. Cost deltas and bounded estimate

Hardware allowances unchanged: $2,320 core, $3,505 expanded, $4,206 expanded with 20% contingency. These remain planning figures, not refreshed vendor quotes. No GPU, robot, or custom carrier purchase introduced.

Slice-1 incremental mandatory service subscription: **$0/month**, assuming a genuine existing Windows license, compliant selected Qt/open-source distribution, and local encrypted backup. It has no mandatory hosting, OIDC, Twilio, SIM, or AI subscription. Existing hardware/consumables, software distribution obligations, support, signing, and engineering are still costs. A SIM is purchased when required for actual phone-ready qualification; no inference that free local software gives free business operation.

First phone-ready planning month excludes Relay and self-hosted Keycloak. Retain Round 1's 300 incoming + 300 outgoing browser-call scenario: $10.30 basic voice; $25–60 SIM estimate; $25 reasoning control only if enabled; $10–25 email/domain/backup allowance only if not already owned. Without hub and managed identity this is $70.30–120.30 including that $25 reasoning allowance. Shared hub adds $33.80 and managed OIDC adds a provisional $0–25, giving $104.10–179.10. Managed identity range is a budget placeholder, not a selected vendor quote. A minimal routing/token backend is required for browser calls even without the composed shared hub; hosted provider functions or a small voice backend must be chosen and priced before those numbers are called a telephone operating budget. Routing, functions, forwarding, taxes, SMS, voice AI, and other excluded charges remain separate; do not silently count such a backend as free.

Round 1 base provider rates were rechecked against the official pricing pages for this round; account-specific terms and identity remain unquoted: [Twilio US voice](https://www.twilio.com/en-us/voice/pricing/us), [DO hosts](https://www.digitalocean.com/pricing/droplets), [storage](https://www.digitalocean.com/pricing/spaces-object-storage), [backups](https://www.digitalocean.com/pricing/backups). Before procurement/activation refresh provider/account rates. No paid service is activated by this document.

Accept 120–200 hours as Grok's provisional **tight Slice-1 target**, not a funded promise. Proposed allocation: domain/RPC/storage 24–40; evidence/serial/documents 24–40; local office/interruption/readiness 16–24; Qt 20–32; backup/import 20–36; integration/package checks 16–28. Total 120–200. The two-day transport spike belongs inside the first allocation, not an uncounted free exercise. At prior $75–150/hour assumptions: $9,000–30,000 labor, or $10,800–36,000 with 20% planning contingency. Actual unknown legacy data, encryption provisioning, Qt distribution requirements, hardware access, and clean Windows packaging can break that estimate. R4 must approve scope/assumptions or revise it; the whole-composition 1,100–1,820 hours remains a separate rough planning range, not the Slice-1 quote.

## 9. Round 4 handoff

Grok should attack the core context boundary, revision semantics, lost-response receipt, staging token lifecycle, per-Home backup/import, and inactive restore. Check whether the 20 methods cover the promised local functions without hidden cloud requirements, and whether CAP71/72 report only observed capabilities. Break the estimate by pointing to a concrete required function, not by reintroducing the whole composition into Slice 1.

Return exact contract deltas, additional reject cases, and a revised work-package estimate where warranted. Freeze changes by revision, never silently rewrite v0. Claude receives the converged design after Glen's rotating rounds. Glen still names the first real mailbox and supplies hardware/provider access when the relevant experiments are scheduled; neither is needed to finish this architectural round.

## Validation receipt for this round

Three formal schemas passed draft-2020-12 structural checks and local cross-file reference resolution with UUID/timestamp format checks enabled. 21 positive instances passed and 35 deliberately invalid instances were rejected, including all 13 command payload branches and raw Home-inbox capture. This validates contract structure only; the domain invariants and Slice-1 functions/tests above are not implemented or executed by this receipt.
