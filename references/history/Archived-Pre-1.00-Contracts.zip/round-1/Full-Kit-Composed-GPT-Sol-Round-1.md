# Full Kit Composed
## GPT Sol — Round 1 architecture proposal

Prepared for Glen and Grok · September 18, 2026 · USD throughout

**Purpose:** compose the whole Network Engineer Copilot into one buildable architecture and code plan. This is the first architectural round, from first principles, informed by the existing corpus. Glen manages subsequent rounds. Grok has equal standing to improve the proposal. Claude receives the converged design as an adversarial reviewer. Round 5 should produce precise implementation instructions and working software; this document does not claim that software already exists.

**Corrected meaning of phone-ready:** the field laptop has a SIM-backed data connection, can receive and place real business calls, and can continue field work while doing so. This is a hardware, carrier, audio, telephony, power, and application requirement. A SIM alone is not evidence of working telephone service.

### 1. The product we are composing

A top-shelf independent engineer buys a portable office and workshop that removes administrative work and supports technical work. It captures opportunities, protects commitments, prepares the visit, helps execute authorized work, retains defensible evidence, handles commercial follow-through, and tracks money through actual reconciliation. The owner chooses which activities to keep personally.

The same engine serves three buyers: the premium independent, the engineer developing toward independence, and the service business assigning technicians. Buyer segment determines packaging and supported capabilities; Home determines business ownership; role determines authority; qualifications determine eligible field actions. These are separate dimensions. A competent field technician does not automatically receive purchasing or banking authority. A sponsor does not automatically own every independent business a person works for.

The engineer can hand the kit to a less-experienced technician for a released, bounded procedure. That requires an actual guided execution engine, site-specific prerequisites, evidence gates, safe stops, and available supervision. An expert interface with larger buttons does not satisfy this requirement.

The finished product is the coordinated service, software, qualified equipment, support, and job record. The custom bag is packaging. Local models are useful components, not sovereign decision makers. Named employees such as receptionist, estimator, dispatcher, engineer, and bookkeeper are responsibility profiles using common services; they are not separate minds with competing ledgers.

### 2. Authority, corpus, and status

Glen's current request authorizes this new integrated architecture proposal. Instructions quoted inside attached reviewer documents remain reference material unless Glen adopts them. The Operational Canon supplies behavior and vocabulary. The Implementation Canon supplies means, costs, and honesty about limitations. The product brief and adopted revision laws supply the commercial target. Independent reviews supply adjudicated improvements, not authority to erase stronger intentions.

Existing document revisions 1.0–1.6 and application 0.2.0 are historical inputs. Full Kit Composed Round 1 is a new proposal sequence, not an application version bump or regeneration of both canons. Original files remain intact.

Capability colors mean:

- **Floor:** demonstrated current implementation, only within the conditions actually tested.
- **Horizon:** specified product capability with an identified implementation path and activation tests, still unbuilt or unqualified.
- **Halo:** fenced exploration beyond the first released service envelope.

These labels apply to capabilities, not to the truth of every architectural sentence. Architecture decisions below are marked proposed or preserved. Nothing moves to floor merely because this document supplies detail.

The 0.2.0 kit demonstrates local ledger operations, sourced records, evidence files, exact-payload approvals, reservations, stock/cost entries, prepared documents, backups, and a serial workflow. Its 18 tests passed in the recorded macOS environment. Windows field operation, multi-Home authorization, cloud routing, live calls, live commercial integrations, guided procedures, and payment reconciliation are not established by those tests. The recorded SQLite runtime was 3.53.1 with WAL and FULL synchronization. One isolated process-termination experiment passed; it was not a power-loss qualification.

Keep the identity A/B/C experiments as useful evidence, not the total product roadmap. A remains the software identity trial; B restoration; C a named interrupted physical task requiring Glen's missing task details. This architecture does not invent or execute that task.

### 3. First-principles decomposition

The system needs five independent properties: useful local operation, one authority for shared commitments, real external execution, attributable evidence, and bounded delegation. A model does not supply any of these by itself.

**Proposed topology D01:** a Windows field application; an always-on cloud hub; a shared deterministic domain engine; local and cloud workers; qualified instrument and business adapters.

```text
                         Customers / vendors / marketplaces
                                      |
                  Hosted business number / communications providers
                                      |
                       Cloud hub: authenticated API + workers
                         PostgreSQL + private evidence storage
                       policy / commitments / receipts / AI budget
                                      |
                           authenticated incremental sync
                                      |
        Windows field application ---- local core ---- local SQLite
          expert / guided / calls       |                evidence store
                                        |
                    procedure / instrument / platform adapters
                                        |
                       authorized site equipment and tools

       Local AI and cloud AI propose work through the same command boundary.
       Calls continue through the provider when the laptop is unavailable.
```

Use a modular monolith initially. Modules share typed contracts and transactional boundaries; they do not need separate deployed services, Kafka, or a distributed agent mesh. Workers are separate processes where necessary, not a collection of independent business authorities. Scale after measuring transaction mix and load.

### 4. Laptop application and process boundaries

**D02 proposed:** Python domain/application services and a PySide6 Qt Widgets desktop. The existing Python prototype makes extraction and migration less risky, while Qt provides a mature native desktop suitable for USB devices, serial sessions, offline files, and large field workflows. The domain engine must have no Qt dependency. Qt for Python provides PySide6 and has LGPL/GPL/commercial licensing options; distribution must qualify the actual modules, notices, replacement rights, and packaging obligations before commercial release. It is not an unconditional zero-license-cost assumption. [Qt for Python](https://doc.qt.io/qtforpython-6/)

**D03 proposed:** launch a separate local core using QProcess. Use newline-framed JSON-RPC 2.0 over its stdin/stdout; diagnostics go to stderr. Enforce a protocol version, 1 MiB frame limit, request IDs, timeouts, and cancellation only before a consequential command is committed. A lost response after commit requires query-by-operation-ID, not automatic resubmission with a new ID. Large documents, photos, captures, and audio use blob handles, never huge inline messages.

The core owns the SQLite write connection and serializes mutations. Read-only views may use separate connections. Instrument capture, extraction, inference, and long exports run in bounded subprocesses and return results to the core. They cannot write the ledger directly. Core failure does not terminate provider call routing. Restart loads pending work from durable state, not the GUI's memory.

No local inbound LAN listener in the default product. A separately authorized phone/tablet companion, if wanted later, adds authenticated pairing and a distinct attack surface; it is not smuggled into the desktop architecture.

**Expert screens:** Today; Portfolio; Job Dossier; Workshop; Calls; Document Desk; Money and Stock; Exceptions; Administration. The Today view shows commitments, readiness, unresolved outcomes, receivables, and useful next actions. Fast capture accepts text, photograph, and qualified local dictation. Direct technical tools remain accessible without a mandatory wizard.

**Guided screens:** assigned job, current released step, exact target, prerequisite checks, action, expected result, required evidence, permitted safe response, and escalation. Explain the reason when a step blocks. A technician can stop honestly without marking completion. Owner review is an explicit obligation with a reserved time window.

### 5. Cloud deployment and authority

**D04 proposed:** FastAPI API, durable worker, PostgreSQL, private object storage, OIDC identity, TLS reverse proxy. Deploy a pilot using Docker Compose on one small Linux host. This reduces operating complexity but is not high availability. A commercial uptime promise requires separately priced redundancy and recovery evidence.

Proposed pilot identity is Keycloak with OIDC authorization-code plus PKCE, enrollment, MFA for privileged actions, short-lived access tokens, protected refresh credentials, and device revocation. Grok should challenge whether managed identity lowers total pilot burden enough to justify its fees and dependency. Do not build passwords, MFA, and account recovery from scratch.

The hub owns shared calendar commitments, outside action coordination, Home policies, device enrollment, tenant access, cloud AI reservations, and reconciled provider receipts. The laptop owns immediate evidence capture and permitted local execution. Both use the same domain rules; deployment context decides which authority can commit a particular transition.

**D05 proposed:** PostgreSQL for the hub from the first shared pilot; SQLite for each local authorized cache. This is a greenfield choice for sponsor concurrency, server authorization, and relational integrity, not a claim that SQLite failed at some seat count. Never share a live SQLite file among laptops or put it in a cloud-sync folder.

Home-scoped composite references, server authorization, and PostgreSQL row security provide layered isolation. The runtime application account must not be a superuser, table owner with bypass behavior, or BYPASSRLS role. Migration and backup accounts are separate. Connection-pool transaction context must not leak a previous request's Home. [PostgreSQL row security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)

Production adds monitored backups, rate limits, upload quotas, dependency patching, signed releases, support procedures, restore drills, and an on-call policy appropriate to promises sold. Avoid claiming SOC 2, regulatory compliance, or certified measurement merely from this stack.

### 6. Domain model: business facts before interface features

**D06 proposed:** typed state tables plus append-only events, audit records, and a transactional outbox. Do not make full event sourcing the initial requirement. Current Job Reality is a revisable sourced projection. A correction changes the current view while preserving what was known and acted upon earlier.

Use UUID identifiers, UTC event times plus source observation times, decimal quantities, integer monetary minor units with currency, explicit revisions, and controlled enums. IDs are not secrets or authorization. Client clocks are not the authority for approval freshness or remote ordering.

Core aggregates and significant relations:

| Domain | Records and responsibility |
|---|---|
| Ownership and authority | Home, principal, membership, role grant, assignment, device enrollment, delegation policy, offline grant, approval |
| Commercial context | customer, contact, site, service agreement, opportunity, qualification, quote, accepted scope revision, change order |
| Portfolio | resource, availability, envelope reservation, appointment, travel allowance, mentor reservation, readiness checklist |
| Job | dossier, sourced observation, current reality projection, obligation, separate tracks, exception, interruption, handoff |
| Identity | asset, observation, assignment, verified bind revision, dispute, temporal replacement/loan/reinstallation relation |
| Execution | platform pack, released procedure, run, step attempt, configuration snapshot/diff, rollback artifact, claim review |
| Workshop | instrument asset, capability, settings/profile, connection session, measurement, calibration/verification status |
| Evidence | immutable original blob, digest, import/capture provenance, extraction, annotation, access/retention classification |
| Materials | item, unit/conversion, lot, owner, stock movement, allocation, receive/consume/return, purchase, warranty |
| Economics | labor/time, expense, cost allocation, invoice version, receivable, payment, fee, refund, dispute, reconciliation |
| Communication | channel entitlement, call/session/participant, consent record, message, delivery attempt, provider receipt |
| Reliability | command receipt, operation attempt, outbox item, external event inbox, sync cursor, conflict, recovery generation |

Every protected table includes Home, directly or through an enforced Home-scoped relation. Cross-Home references are rejected by database constraints and application checks. Shared public reference documents occupy a deliberately separate namespace. Private customer precedents never become globally shared examples automatically.

A person can belong to several Homes. Switching Home changes retrieval context, dossiers, calls, calendars, approvals, model budgets, cached secrets, and exports together. Cross-business calendar availability can share opaque busy intervals under permission without exposing another Home's customer or economics. Technician assignment caches contain the permitted subset; owner financial details are not silently downloaded.

Local OS encryption and per-Home protected credential references protect ordinary loss/theft scenarios. A local administrator can inspect data the device has legitimately downloaded; do not promise invulnerable tenant isolation against its own hostile administrator. Minimize caches and invalidate access on reconnect. Server-only information never enters the cache without entitlement.

Retention is explicit by data class and contract: database facts, originals, packet captures, dictation audio, call recordings, summaries, exports, backups, and provider copies. A legal hold is a named exception, not a reason to keep all data forever. Deletion tracks live copies, cached copies on reconnect, scheduled backup expiry, and provider obligations; it does not claim instant erasure from an offline device or immutable historical backup. Audit payloads minimize personal data and secrets so retained accountability does not secretly retain deleted content. Encryption keys and recovery custody require a tested owner/support policy.

### 7. Commands, policy, and operations

**D07 preserved behavior, proposed implementation:** all consequential work passes through one deterministic command boundary. Neither GUI, adapter, nor model may bypass it. Example commands: CreateJob, RecordObservation, VerifyAssetBind, ReserveEnvelope, AcceptScope, AuthorizeOperation, StartProcedureStep, RecordMeasurement, InterruptWork, IssueInvoice, ReconcilePayment. Query interfaces return scoped views, not unrestricted table access.

A command carries protocol version; operation ID; Home; actor/session; device; job if applicable; expected aggregate/scope revision; action type; typed payload; evidence references; authority references; and requested execution context. The server derives the authenticated principal and allowed Home from the session; a client-supplied actor name never establishes identity.

Processing order: authenticate; authorize Home/resource; validate schema; check operation receipt; check expected revision; resolve standing policy or exact approval; verify prerequisites and capability; validate budget/reservation constraints; commit state/event/outbox/receipt atomically; then execute outside effects through a worker.

Approval digest uses a versioned canonical encoding of the exact action payload, Home, job and scope revision, policy revision, assets/binds, applicable pack/procedure versions, amount/currency, destination/account, execution limits, and expiry. Preserve approval history when invalidated. Do not equate a digest with a cryptographic signature or proof a human read the payload. Approval capture is attributed to an authenticated authorized session in the new implementation.

Operation states: prepared, queued, executing, confirmed, failed, unknown, reversed, manual-reconciliation-required. Delegation capabilities: suggest, prepare, queue, execute, reconcile. These describe different things. A queued invoice is not issued; a sent invoice is not paid; delivery is not acceptance.

Adapters implement validate-entitlement, prepare, execute, query-status where supported, normalize-receipt, and classify-failure. Each declares idempotency support and what confirmation actually means. If a provider might have accepted an action before timeout, retain unknown status and reservations. Retry only after authoritative reconciliation or a documented human decision. Never advertise exactly-once execution across arbitrary providers.

Webhook inbox verifies provider authenticity, deduplicates provider event IDs, rejects replay outside accepted policy where applicable, and links events by scoped account/operation identifiers. Notifications can be delayed or out of order. Querying a provider may establish a newer outcome; it does not erase older events.

### 8. Offline operation and synchronization

**D08 proposed:** incremental command/event synchronization with server acknowledgments, deterministic conflict handling, and no last-write-wins for authority, scope, identity disputes, money, or commitments. Evidence uploads are resumable; server verifies digests before accepting references as available. Uploading a hash is not uploading the evidence.

Offline work allowed: capture evidence, observations, time, stock consumption within authorized assignment, local drafts, qualified local assistance, and already-authorized physical/configuration steps explicitly allowed by the procedure and bounded grant. New shared commitments, marketplace acceptance, purchases, issued invoices, payments, and external messages wait for cloud authority or a separately evidenced external human action.

Offline grants are issuer-signed and bind Home, principal/device, job/scope/policy revisions, allowed action classes, expiry, maximum offline age, relevant exposure limits, cached prerequisites, and checks that require connectivity. A disconnected device cannot learn revocation instantly. Limit grant duration and privilege accordingly. Detect clock rollback using signed server time anchors and monotonic elapsed time within a boot; if trustworthy elapsed time across reboot is unavailable, block affected high-risk offline actions until online renewal. Evidence capture still works.

Local observations remain historical facts even when the server later reports revoked assignment or changed scope. Reconnect may produce an unauthorized-work exception; it must not retroactively manufacture approval. Conflicting proposals become review items. Shared reservations are accepted or rejected by server revision and constraints, not merged arbitrarily.

Physical configuration writes have a resource lease tied to target identity and local session; shared coordination plus explicit ownership reduces simultaneous writers. Do not claim a cloud lease prevents a second technician using an unrelated terminal. Procedures require checking active maintenance control and actual site coordination.

### 9. Safe interruption, restore, and durability

**D09 preserved:** scope/policy/asset/procedure changes invalidate affected normal authority. Stop at the approved safe boundary; do not abruptly abandon exposed equipment or finish the changed scope. Each released step identifies narrow stabilization actions, their authority, and when qualified help is needed.

Interruption record: trigger; old/new revisions; interrupted step; last verified state; exposed cabling/equipment/access; service impact; reversible and irreversible changes; risks/unknowns; permitted stabilization; actual result/evidence; hold conditions; responsible person; required decision. States: detected, stabilizing, secured/on hold, stabilization failed/escalated. Unaffected work proceeds only with valid independent dependencies. Resume requires current reality check, revised procedure where needed, and renewed authority.

**D10 proposed storage protocol:** stage blob on the same local filesystem, stream hash, flush file, atomically publish by digest, then commit metadata/event/outbox. If metadata commit fails, the unreferenced published blob is recoverable garbage, not an invented evidence record. Never commit a reference as available before its blob is durably published. Recovery reconciles staging, referenced missing blobs, and orphan files. Validate the actual Windows filesystem/power behavior; fsync assumptions are not a guarantee against broken hardware.

Local SQLite uses WAL, FULL synchronization, foreign keys, bounded transactions, busy handling, and single writer ownership. Runtime startup checks the linked SQLite version against the supported patched set; do not infer it from Python. SQLite documents a WAL-reset race corrected in 3.51.3 and specified backports. [SQLite WAL documentation](https://www.sqlite.org/wal.html)

Backup contains a consistent database snapshot plus a manifest and all referenced evidence, protected with recoverable encryption. Pilot can pause local writes during backup; a failed/incomplete manifest is not a successful backup. Cloud requires PostgreSQL-consistent backup plus evidence inventory and restoration tests, not VM snapshot alone.

A restored ledger preserves lineage but starts inactive for external effects. Home, device identity, ledger lineage, and recovery generation are distinct. Controlled cutover disables the old writer and checks provider outcomes before activating restored queues. On a disconnected lost device, revocation reaches it only on reconnect or grant expiry; narrow offline grants bound remaining exposure.

Proposed pilot targets, to be accepted before qualification: no loss of acknowledged local transactions under the supported crash model; remote core-record recovery point at most 24 hours for the lean deployment; next-business-day restoration from independent backup. Higher commercial recovery/availability guarantees need different operations and cost. Evidence upload latency remains separately visible.

### 10. Serial once, assets, and measurement honesty

**D11 preserved:** capture the label once as an observation, assign it explicitly, verify a bind, then recall only from the active verified bind. OCR or transcription cannot silently become verified identity. A disputed or missing bind returns unresolved. A corrected bind appends a revision; previously prepared documents retain their original snapshot.

Proposed data shape:

```json
{
  "home_id": "UUID", "job_id": "UUID", "asset_id": "UUID",
  "observation_id": "UUID", "identity_kind": "serial",
  "raw_value": "as observed", "normalized_value": "pack-defined",
  "source_evidence_ids": ["UUID"], "capture_method": "typed|photo|local_dictation",
  "claimed_observer": "source attribution", "authenticated_principal_id": "UUID or null",
  "assignment_revision": 1, "bind_id": "UUID", "bind_revision": 1,
  "verification": {"method": "human_label_check", "evidence_ids": ["UUID"]},
  "state": "verified|disputed|superseded"
}
```

This is an explanatory shape, not a proposed flat replacement for normalized tables or a claim that every field exists in 0.2.0. Unverified observations do not have a verified bind. Revision zero means no bind in the existing CLI; stored binds start at one. Migration must preserve these semantics.

Replacement relation includes old/new assets and bind snapshots, effective time, location/function, reason, evidence, temporary/permanent/reinstallation classification, return disposition, and warranty references. Keep both-direction temporal lookup. A reinstalled old device is not an impossible permanent ancestry tree. Serial correction and equipment replacement are different events.

Measurements record target, instrument bind/capability, operator, setup/endpoints, settings, units, raw output, timestamps, calibration/verification condition, and applicable criterion. Derivations reference raw measurements and algorithm/version. Manually entered readings remain manual. Imported photographs may support placement or labels; they cannot certify torque, cable category performance, electrical safety, or optical loss by themselves.

### 11. Two local AI capabilities plus cloud when useful

**D12 proposed:** two distinct local capabilities, not two always-running large chat models: (1) a quantized small language model for qualified local search, briefing, extraction, and drafting; (2) local speech recognition for dictation and, after evaluation, lightweight image/OCR extraction using separate tools. Glen's “2 local AI plus cloud” is interpreted this way for the lean kit; if he means two independent reasoning models, make that a measured alternative rather than buy a GPU reflexively.

Candidate runtime: Ollama for text inference and whisper.cpp for local dictation. Their existence does not establish acceptable speed on the refurbished laptop. Select the actual model, quantization, context, language coverage, license, memory use, and latency using field tasks. Run heavy models on demand, bounded concurrency, and give capture/calls priority. [Ollama API](https://docs.ollama.com/api/introduction), [whisper.cpp](https://github.com/ggml-org/whisper.cpp)

Cloud is normal, especially for difficult troubleshooting, complex document comparison, and image reasoning. Routing uses task requirements, measured accuracy/latency, context size, connectivity, Home/customer egress policy, and cost. No ritual local failure first. Model self-confidence is not a gate. Cloud model/provider identities remain a Round 3 evaluation decision rather than a fabricated API identifier.

Retrieval starts with Home-scoped metadata, full-text search, released packs, and provenance links. Add embeddings only if evaluation shows a material improvement; if used, vectors and chunks retain Home and access rules. Field reference documents and device output are untrusted inputs, not instructions granting model tools.

The model receives the minimum allowed dossier view, returns a typed proposal with sources/unknowns, and cannot execute raw shell, arbitrary URLs, purchases, or unrestricted device commands. Authorized diagnostic plans select known operations through the command boundary. Secret references resolve only inside permitted adapter sessions; credentials never enter a generic reasoning prompt.

Gateway reserves estimated maximum cost atomically, restricts output/tool limits, then reconciles usage. Unknown provider costs retain reservations. Proposed allowance is $25 per active technician/month, with an owner-set $50 ceiling for reasoning; continuous voice has its own budget. Exhaustion produces a visible limitation and local/manual option, not silent premium escalation.

### 12. Laptop calls and the Voice Bridge

**D13 proposed:** Twilio hosted business number; browser Voice SDK on supported Windows Edge/Chrome over the laptop's SIM data; native dossier call cards; independent hosted routing and fallback. Browser console is a small TypeScript application served over HTTPS. Tokens come from the authenticated hub, narrowly scoped to the enrolled user and account. No master telephone credential on the laptop.

Microsoft's cellular guidance describes SIM/eSIM as network connectivity. Qualify exact WWAN module, antenna installation, firmware, carrier plan, band coverage, sleep behavior, and Windows driver. Direct carrier-native voice is optional only after proving the exact modem/plan/API combination. [Windows cellular settings](https://support.microsoft.com/en-us/windows/experience/connectivity-networking/cellular-settings-in-windows)

The Twilio SDK documents supported desktop browsers. Use a supported browser first; do not infer QtWebEngine support. This introduces a separate audio console, an honest UX cost. The desktop remains the job surface; the browser handles real microphone/speaker/call state. Deep-linking opens a scoped call session; authoritative call events update both surfaces through the hub. A browser reconnect never fabricates participation. Grok should compare this with a unified web/Tauri surface using an actual supported voice path. [Twilio JavaScript Voice SDK](https://www.twilio.com/docs/voice/sdks/javascript)

Inbound path: provider receives call; unrecorded menu/routing determines intent; ring registered owner endpoint if present; on no answer/unreachable route to the existing fallback number or an approved callback flow. Server routing has bounded response time and a provider-hosted fallback if the application hub fails. Outbound calls require channel entitlement and action policy. Test speaker/microphone permissions, Bluetooth reconnection, headset controls, concurrent instrument acquisition, weak cellular uplink, sleep, and resume.

For conversational secretary, propose ConversationRelay rather than building a raw audio/STT/TTS pipeline first. It handles speech interfaces and exchanges text with the application; the application still controls model access and business actions. Availability, supported configuration, latency, retention, consent, and price require qualification. If unavailable, real menu/routing and human fallback continue; the UI never presents an absent AI secretary as online. [ConversationRelay](https://www.twilio.com/docs/voice/conversationrelay)

Receptionist may capture intake, answer verified business facts, propose slots, and book only through the deterministic reservation transaction and owner policy. Caller statements are observations. Claimed identity is not proof of account access. It cannot disclose private dossiers or make unsupported promises.

Voice Bridge is dossier-on-a-circuit: participants receive a role-scoped brief, actual conference connection state, and the question being escalated. Listen-along means genuinely connected with microphone muted; hot join means connected and explicitly enabled to speak. Joining, muted, held, disconnected, and failed are distinct. Twilio conferences support muted participants; muted is not the same as held. [Conference controls](https://www.twilio.com/docs/voice/conference)

Recording, transcription, speech processing, AI participation, retained summary, and third-party joining require separately reviewed handling. Unknown/declined permission blocks affected modes and offers nonrecording alternatives. Consent capture must not secretly record before permission; new participants and withdrawal reevaluate applicable modes. Qualified multi-jurisdiction review is required before activation, rather than a universal checkbox claiming compliance.

### 13. Scheduling, opportunities, and fit-pricing

**D14 preserved:** schedule the operational envelope, not just hands-on duration. Store access windows, preparation, travel, installation, uncertainty/contingency, documentation, replenishment, and aftercare. Reserve technician, vehicle, required instrument, and mentor attention where applicable. Hard commitments cannot be consumed by an attractive opportunity.

The engine uses timezone-aware intervals and named site timezones. Use manual conservative travel allowance offline; online routing estimates are sourced and time-bounded, not guarantees. Overrun opens a conflict task with impact and authorized options. Rescheduling communicates only through the permitted adapter and confirmation path.

Lead intake supports calls, private referrals, customer requests, imported listings, and permitted marketplace APIs. Qualification records geography, access, work type, skill, prerequisites, margin, risk, payment terms, and capacity. Fit-pricing computes labor band, direct parts/landed cost, travel, protected attention, overhead, contingency, and margin. A model explains tradeoffs; it is not an auctioneer bidding autonomously.

A price decrease must be within owner policy, not degrade competence/attention promises or violate a minimum. Apprenticeship graduation changes released capability, eligible commercial band, and reserved supervision together, based on observed evidence and owner decision. Correct escalation is a positive outcome; it is not automatic graduation.

Field Nation integration requires the actual account's credentials, entitlement, and permitted actions. API documentation alone does not prove a worker can accept/request every operation. First support sourced import and clear manual handoff; add real API operations only after account qualification. Never synthesize platform receipts. [Field Nation prerequisites](https://developer.fieldnation.com/docs/getting-started/prerequisites/)

### 14. Workshop, instruments, and platform packs

**D15 proposed instrument capability enum:** COPPER_WIREMAP, COPPER_LENGTH_ESTIMATE, COPPER_CERTIFICATION, ETHERNET_LINK, ETHERNET_THROUGHPUT, POE_PRESENCE, POE_LOAD_TEST, WIFI_SCAN, WIFI_SURVEY, OPTICAL_POWER, OPTICAL_LOSS, FIBER_END_FACE, DC_VOLTAGE, AC_VOLTAGE, CONTINUITY, WAVEFORM, DIGITAL_LOGIC, RS232, RS485, CAN, RF_SPECTRUM, THERMAL_IMAGE, CCTV_IP, CCTV_ANALOG, COAX_MAP, ANALOG_LINE, ROBOT_ACTUATION.

Enum names describe capability classes, not entitlement or performance. Each concrete instrument declares supported ranges, rated safety, test setup, interface type, driver version, raw export, and qualification status. Acquisition modes: automated driver; vendor-tool file import; explicit manual reading with photo/raw source; unavailable. Do not substitute cheap wiremap for COPPER_CERTIFICATION or PoE detection for full load qualification.

First low-cost path uses existing host NIC/Wi-Fi, a known-good endpoint, Wireshark/tshark capture under authorization, iperf3 between authorized endpoints, real serial console, inexpensive copper diagnostics, independent multimeter, labeler, and manual instrument records. Quote/rent a calibrated certification instrument when the contract requires it. A manual acquisition implementation is a real function if the workflow says manual; it is not an automated driver stub.

Separate cellular/business connectivity from the customer test interface. Disable Internet Connection Sharing, bridging, and IP forwarding by default; verify routes and adapter metrics before connection. Bind capture/diagnostic operations to the selected authorized interface and target range. Customer traffic must not gain a route through the laptop SIM. Host processes can still reach a connected customer network, so interface selection alone is not a security sandbox: use firewall profiles, explicit egress restrictions, minimal credential exposure, and a dedicated isolated test VM/adapter where the threat requires it. Add this to the installation/readiness checks and test it while calls and inference are active.

Evidence intake supports laptop camera, selected files, and explicit imports from a separate phone/camera. A phone thermal accessory may require that compatible host; it is not presumed to work plugged into the laptop. Standalone instruments remain functional without USB integration. Record capture/import origin and do not claim EXIF proves current site conditions.

USB scope/logic tools are for qualified isolated low-voltage work. Never attach a grounded USB oscilloscope to arbitrary mains or unknown industrial potential. Confirm voltage/safety limits, isolation, lead ratings, and required competence. Thermal accessory host compatibility and authentic RF unit sourcing need qualification. No price allowance proves a driver works.

Fiber cleaning/basic measurement records can be captured, but released guided fiber work, fusion splicing, automated end-face judgments, robots, and custom carrier remain halo until their own evidence warrants expansion. Robotics plugs into instrument/action contracts with safety interlocks and authority; an enum does not make a robot safe.

**D16 preserved semantics:** Platform Packs translate supported intent, not vendor strings. A Cisco-familiar engineer should see the same intended outcome while device-specific semantics remain explicit. ArubaOS-Switch and Aruba CX are distinct. Hirschmann family/firmware must be bound, not guessed.

A first Aruba CX pack declares model/firmware applicability, official sources, retrieval commands, interface naming, VLAN/tagging semantics, management reachability, checkpoint/save behavior, expected parsed results, supported actions, evidence gates, rollback procedure, and revocation triggers. An unsupported firmware blocks generated write operations. Read-only inspection can remain available with an uncertainty label.

Build a desired-state plan, compare actual state, show a semantic diff, validate out-of-band recovery, authorize the exact change, apply bounded commands, capture outputs, reread actual state, and test reachability/service. A returned prompt is not proof success. A pack update does not silently rewrite a procedure already in progress. Golden transcripts plus an exact supported lab device qualify the pack.

### 15. Procedure engine and supported service

**D17 proposed:** released declarative procedures evaluated by a deterministic state machine. YAML/JSON authoring is validated against a strict schema and compiled into immutable release artifacts. No arbitrary Python inside customer-authored steps.

Each step contains applicability, required prior states, named target, allowed actor/qualifications, tools/capabilities, exact action or controlled command template, required evidence/criterion, retry policy, dependencies, stop conditions, safe-boundary response, and escalation. Outcomes distinguish passed, failed, blocked, skipped-by-authority, not-applicable-by-authority, and pending review. A clicked checkbox cannot satisfy a required measurement.

First released guided service: a bounded small-business switch/AP installation or replacement under preapproved topology with existing suitable cabling/power, exact supported hardware, recovery path, and available mentor. This defines the first validated procedure, not the entire application boundary. Expert recording and advice remain useful for other work without claiming validated novice execution.

Photo/OCR assists evidence review with uncertainty. Missing views, stale imports, mismatched labels, contradictory tests, and topology drift must remain visible. Human expert review gates critical interpretation until comparative trials establish the narrower automation that can be trusted.

### 16. Materials, documents, money, and final paycheck

**D18 preserved:** separate operational, delivery/acceptance, billing/payment, returns, and exception tracks. Milestones are derived summaries. Scope contracts control invoice timing: deposits and milestone bills may precede field completion. Do not make acceptance-before-invoice universal.

Inventory uses movements, lot/ownership, fractional units, explicit conversions, reservations, receiving, consumption, and returns. Owned stock, customer-supplied parts, rental tools, and consignment differ. Landed cost includes applicable freight/tax allocation; markup and margin are separately calculated. Purchasing has actual vendor/account entitlement, spend reservation, confirmation, and unknown-result handling. Initially a sourced manual order/receipt can be real without pretending automation.

Document Desk uses versioned templates, immutable prepared snapshots, source references, approved disclosure views, and actual PDF page operations. Propose HTML-to-PDF through a qualified rendering engine, PDF composition with pypdf, and LibreOffice only for formats requiring it. Record the exact rendering environment for reproducibility. Signatures refer to exact document version and attributed signer/context; a drawn image is not automatically a qualified electronic-signature product.

Printing records local spool submission and failure; spool success does not prove paper emerged. SMS uses an entitled number and qualified messaging account, with actual consent/opt-out handling, any required sender registration, segment-based billing, and provider receipts; these costs are quoted separately. Email uses the authorized mailbox/provider; delivery means the provider's actual accepted/delivered state, not guaranteed reading. Fax/portal APIs need actual accounts. Without them, generate the exact package and a human task, then record sourced submission evidence. Insurance records use actual policy/certificate documents, expiries, and named coverage; the system does not manufacture certificates or decide legal coverage.

Billing keeps invoice versions, accepted change orders, line items, taxes as configured/reviewed, time, expenses, parts, and contract terms. An invoice becomes issued only through a verified adapter outcome or explicit sourced human issuance. Reconciliation links external bank/payment/accounting evidence to receivables; supports partial allocations, fees, credit notes, refunds, reversals, chargebacks, and unresolved differences. Never store raw card data; use hosted provider facilities.

Choose one actual email/calendar account and one accounting/payment workflow during Round 3; do not scaffold ten pretend integrations. Candidate alternatives must be evaluated against Glen's real accounts and entitlements. Bank statement import plus human reconciliation is an honest first functional path if a live bank feed is unavailable. The architecture retains an interface for feeds and hosted payments.

Warranty, callbacks, return disposition, maintenance reminders, collections, and actual profitability follow the same dossier. Final paycheck means evidenced settlement allocation, not an invoice ticked paid by a model. Owner attention spent on exceptions belongs in the economics.

### 17. Full functional coverage and release truth

Appendix A, also exported as Capability-Catalogue.csv, maps every major function to module, first functional path, activation evidence, and floor/horizon/halo status. It is a build traceability document, not a list of pretend connected features.

Every displayed action checks a versioned capability registry: implemented, installed, configured, entitled, available, qualified, and permitted in this context. These are separate checks. A released UI either executes a real path, offers an explicit sourced manual workflow, or explains the unavailable capability. No success-returning dummy adapters, TODO handlers, fabricated readings, simulated bookings, empty ASR functions, or model-written payment receipts.

Fixtures and fake providers are permitted in isolated tests only, clearly separated from production configuration. Demonstrations using them are labeled simulations. Commercial copy cannot say “literally do anything,” “dumb hands perfect splice,” “the AI handles the ecosystem,” or “the model is bidding the jobs.” The product promise should describe released outcomes and supported procedures.

### 18. Repository and contracts for the next coding rounds

**D19 proposed repository:**

```text
fullkit/
  packages/domain/          types, invariants, policy, money, scheduling, transitions
  packages/application/     commands, queries, orchestration, ports, unit-of-work
  apps/desktop/             PySide6 expert/guided screens, local RPC client
  apps/edge/                core process, local repositories, sync, worker supervision
  apps/hub/                 FastAPI, session authorization, webhooks, cloud repositories
  apps/worker/              durable outbox, reconciliation, cloud AI gateway
  apps/voice-console/       supported-browser SDK, real audio/call state
  adapters/                 sqlite, postgres, blobs, serial, instruments, business providers
  packs/                    source-backed platform packs and released procedures
  migrations/               local/server schemas, audited 0.2.0 import
  deploy/                   pinned Windows install/build and cloud Compose configurations
  tests/                    domain, contract, integration, fault, isolation, lab transcripts
  docs/                     contracts, support matrix, security, recovery, validation, costs
```

Dependency rule: domain imports no UI/provider/storage SDK; application depends on domain/ports; adapters implement ports; entry points compose dependencies. Provider exceptions normalize into declared outcomes without erasing raw receipts. Avoid a service-locator global that makes authorization optional.

Before generating feature code, freeze schema versions for command/receipt, evidence manifest, sync batch/ack/conflict, offline grant, procedure release/run, instrument result, platform plan, external operation/receipt, call session, and model proposal. Specify examples, rejection cases, and migration policy. OpenAPI describes the hub; JSON schemas describe local RPC and durable payloads. Share enums and test vectors through generated artifacts, not handwritten drifting copies.

Build/package on Windows for Windows. Produce signed installer/update packages when signing is provisioned; test clean installation, uninstall retention choices, rollback, PATH/tool discovery, device drivers, firewalls, and least privilege. Separate ordinary user capture from tools that actually require elevation. Pin a supported dependency set after checking security and licensing; do not invent version pins in an architecture paper.

Installer is idempotent: inventory prerequisites, install approved components, provision folders/ACLs, verify versions/runtime, enroll device, qualify chosen tools, test capture/backup/calls, and publish a readiness report. Missing optional tools disable affected capabilities. An interrupted installation resumes safely. Credentials are provisioned into protected stores through reviewed account flows, never pasted into the code package.

### 19. Migration and code generation sequence

Do not build the new system by decorating the Tk command form indefinitely, and do not throw away tested domain behavior merely to call the result greenfield. Extract invariants and test cases, redesign boundaries, and import data explicitly.

0.2.0 migration: preserve the original read-only ledger/evidence; inspect version and integrity; select the destination Home under Glen's authority; map old IDs to new namespaced records; retain claimed actor attribution as claimed, not authenticated; preserve serial bind revisions/document snapshots; migrate actual supported stock/cost data with reconciliation; report unknown fields/units; compare counts/digests; write an import receipt. Do not migrate pending external effects into executable queues. Rollback retains the old kit; do not run two active writers for the same commitments.

Code generation slices, each ending in a running demonstrable function:

1. **Kernel and native capture:** Home/identity/auth context, typed commands, SQLite, evidence, audit/outbox, actual GUI intake, crash/restart, serial-once, job tracks, interruption records, encrypted backup/restore. Show two Homes cannot mix through normal application paths.
2. **Cloud authority and sync:** OIDC enrollment, PostgreSQL isolation, grants, canonical scheduling reservations, incremental uploads, conflicts, restore cutover, atomic model budgets. Disconnect/reconnect during capture and scope revision.
3. **Workshop and one released pack:** real serial/network acquisition, sourced manual instrument records, desired-state diff, exact asset binding, local assistance, versioned bounded procedure and expert review. Lab hardware required for write qualification.
4. **One real office action:** actual authorized routine customer update, provider receipt, timeout/reconciliation, duplication defense, attention measurement. Prepared-only functionality already works before issuance is activated.
5. **Real laptop telephone:** supported browser endpoint, inbound/outbound calls, fallback on sleep/hub failure, dossier association, permission gates; then conversational intake and bridge under separate qualification.
6. **Business loop:** real quote acceptance/scheduling, stock/purchase path, closeout delivery, invoice issuance, actual payment evidence/reconciliation, dispute/return/aftercare. Guided installation field trial under exact supported conditions.

This sequence builds the complete agreed model progressively. It does not redefine the product as a serial capture tool or promise all services are automated in slice one. A slice fails completion if it contains production stubs for its declared working outcomes.

### 20. Proof-of-concept equipment and operating costs

Hardware allowance from the existing September 18 budget, not refreshed vendor quotations:

| Item | USD |
|---|---:|
| Refurbished FZ-55 Mk1, 16 GB/512 GB, Windows 11 Pro and charger | 800 |
| RAM upgrade to 32 GB | 65 |
| Spare OEM-compatible battery | 100 |
| Installed carrier-compatible WWAN option | 140 |
| Encrypted backup SSD, 1 TB | 75 |
| USB Ethernet and powered hub | 55 |
| RS232 console/adapters/cables | 50 |
| Economy copper/optical-power diagnostic tool | 120 |
| Fiber cleaners/adapters/known-good leads | 75 |
| Independent MM400-class multimeter | 65 |
| Termination/punchdown/strip tools | 120 |
| Patch leads/couplers/passive adapters | 65 |
| Standalone labeler and tape | 55 |
| Headset | 40 |
| Used portable printer/power/ink allowance | 180 |
| Padded pouches | 50 |
| Commodity duffel/base/straps | 90 |
| Hand cart | 50 |
| PPE/headlamp/ESD consumables | 50 |
| Known-good managed test switch and PoE injector | 75 |
| **Core** | **2,320** |

Extended allowances: USB scope $80; logic analyzer $20; isolated RS485 $45; authentic tinySA-class RF unit $220; thermal accessory $220; fiber inspection probe $140; optical source $80; CCTV tester $180; coax mapper $35; soldering kit $65; analog butt set $60; extra leads/padding $40. **Extended addition $1,185; combined $3,505; 20% contingency $4,206.** Core with the same 20% contingency is $2,784.

Buy core first, borrow/rent contract-required certification, and purchase extensions only against representative work. If the supported-service lab needs an AP or another traffic endpoint not already owned, budget it separately from these totals. The old optional spare endpoint allowance is $100, not a current quote. Carrier activation/SIM/shipping/tax, refurbishment defects, AP hardware, exact adapter compatibility, replacement consumables, and calibration/rental are not magically inside contingency.

Qualify the exact refurbished SKU before purchase: legitimate supported Windows installation/CPU, battery condition, ports, BIOS access, antennas, actual WWAN module, carrier bands and approval, RAM compatibility, driver availability, and repair/return terms. A different FZ-55 generation's specification does not prove the offered Mk1 has its features.

Proposed fresh monthly pilot scenario, replacing rather than adding to old bundled telephone estimates:

| Component | Basis | Monthly USD |
|---|---|---:|
| Hub host | Current DO Basic 4 GiB/2 vCPU tier | 24.00 |
| Object storage | Current Spaces base | 5.00 |
| Weekly VM backup | 20% of host, additional application backups required | 4.80 |
| Business number and basic voice | 300 inbound + 300 outbound laptop-browser minutes | 10.30 |
| Reasoning allowance | Proposed control, not measured consumption | 25.00 |
| SIM data plan | Planning range, actual carrier quote required | 25–60 |
| Domain, authorized email, other backup allowance | Planning range; avoid paying again if already owned | 10–25 |
| **Scenario subtotal** | Not total business or commercial cost | **104.10–154.10** |

Host/storage/backup pricing sources: [Droplets](https://www.digitalocean.com/pricing/droplets), [Spaces](https://www.digitalocean.com/pricing/spaces-object-storage), [Backups](https://www.digitalocean.com/pricing/backups). If 4 GiB cannot support the measured identity/database/API workload, the $48 8 GiB tier makes that three-line subtotal $62.60, increasing this scenario by $28.80. No cloud GPU is included.

Basic voice arithmetic from current US listed rates: $1.15 local number + 300 × ($0.0085 inbound PSTN + $0.004 browser) + 300 × ($0.014 outbound PSTN + $0.004 browser) = $10.30. Taxes, conference participant legs, forwarding fallback, recording, transcription, conversational secretary, SMS, and AI are additional. Current listed ConversationRelay price is $0.07/minute: 300 secretary minutes add a $21 usage allowance before the application's voice-model cost. If Relay replaces a browser leg, recalculate that leg rather than double-counting it. For conservative planning, adding $21 Relay and a separate proposed $10 voice-model allowance to the scenario gives $135.10–185.10/month; this is still not an all-inclusive bill. Confirm account pricing and any speech-option supplements before activation. [Twilio US voice rates](https://www.twilio.com/en-us/voice/pricing/us)

Telephony usage alerts are not a guaranteed hard ceiling. Application limits, destination restrictions, concurrent-call limits, inference reservations, and a reviewed stop/routing policy bound exposure, subject to provider metering delay. Do not cut safety-critical customer communication just to preserve a reasoning allowance. [Twilio usage triggers](https://www.twilio.com/docs/usage/api/usage-trigger)

Recurring exclusions requiring real quotes: accounting/CRM/e-signature/fax subscriptions, payment fees, managed identity if selected, commercial Qt license if required, Windows licensing beyond the genuine OEM entitlement, signing certificate, insurance, calibration, taxes, data overages, human review, support, monitoring, secure release operations, redundancy, and legal review. Most named open-source components have no per-seat purchase price, but licenses and support still require qualification.

Original $18k–$72k pilot engineering range (240–480 hours at $75–$150/hour) is historical and too narrow to call this full commercial implementation funded. Illustrative new estimate for budgeting, not a commitment: domain/local/evidence/migration 180–280 hours; native expert/guided UI 160–260; cloud/auth/sync/recovery 220–360; business/document/economic workflows 180–300; voice/AI/one pack/instrument qualification 180–320; packaging/security/field validation 180–300. Total 1,100–1,820 hours, or $82,500–$273,000 at that rate range, before contingency, external review, and additional connectors/procedures. R4 should replace this rough estimate with work-package estimates grounded in selected accounts/hardware and accepted scope. AI code generation may reduce some coding time; it does not erase field qualification or operating responsibility.

The $10,000 seat remains a commercial hypothesis. BOM, buyer operating cost, seller hosting/support, liability, training, returns/warranty, gross margin, and willingness to pay require separate analysis. Three buyer packages can expose different supported capabilities without creating three incompatible engines.

### 21. Acceptance, adversarial cases, and R&D

Tests should prove a failure would materially matter, not merely echo implementations. Retain the twelve original ledger behavior tests and serial cases as regression specifications where applicable; rewrite them against new interfaces without implying legacy tests cover new tenancy or cloud behavior.

Required adversarial cases: cross-Home retrieval/export/vector/webhook; forged client actor; stale approval after scope/asset/pack changes; interrupted exposed mock installation; offline grant expiry/reboot/clock rollback; duplicate request after lost response; provider accepted then timed out; duplicate/out-of-order webhook; restore replay of pending invoice; two technicians fighting for a reservation; blob published without metadata and vice versa; missing/forged photo; unsupported firmware; wrong serial normalization; model prompt injection in device output; exhausted concurrent AI budget; microphone permission loss; laptop sleep during ringing; hub outage during live call; consent refusal/new participant/withdrawal; partial payment, fee, reversal, and chargeback; milestone invoice before operational completion; stock conversion/ownership/return errors.

Controlled end-to-end demonstration: actual request, accepted scope, prep photos, kit readiness, authorized installation, sourced tests, handover delivery, invoice issuance, and reconciled payment. Run expert and guided modes; record total owner minutes including review/reconciliation, technician errors, proper escalations, rework, cost per job, downtime, and recovery. A scripted happy path does not prove commercial readiness.

Proposed initial release gates to ratify in R4: every consequential outcome traceable to authority and receipt; no duplicate financial action in the specified retry suite; no cross-Home exposure in the full boundary suite; no unsupported critical procedure advancement; tested clean target-Windows installation; successful independent restoration; real call fallback; and at least three representative supported guided jobs independently inspected by an expert. Those trials are an initial gate, not statistical proof of universal reliability. Set measurable administrative-time and error thresholds from baseline work before claiming savings.

R&D list: acceptable CPU-only local latency; robust photo/scene interpretation; semantic vendor configuration equivalence; safe novice guidance across topology drift; microphone/noisy-site transcription; WWAN sleep/recovery and fallback usability; instrument interoperability/calibration; model error calibration; broader guided packs; managed concurrency/capacity; optimal packaging; fiber/splicing/robotics. Ordinary integration engineering—actual authentication, sync, authorization, backups, provider receipts—is difficult but is not excused as indefinite R&D.

### 22. Decisions offered to Grok, and round handoff

Preserved laws: separate evidence/authority/outcome tracks; exact approvals and standing delegation; honest measurements; Home/role/competence separation; fit-pricing and protected envelopes; serial recall from binds; meaningful safe stop; cloud-normal hybrid; genuine participation/permission; apprenticeship attention coupled to capability; no imaginary connectors; custom carrier/fiber robotics fenced.

Grok should challenge these proposed implementation choices with concrete alternatives:

1. Native PySide6 plus supported-browser voice versus one web/Tauri surface. Compare hardware access, offline deployment, voice support, maintenance burden, and actual expert experience.
2. Python shared domain versus another core language. Compare validation/contracts, native tooling, migration leverage, and developer burden without declaring language preference a proof.
3. PostgreSQL hub immediately versus a serialized single-node SQLite service. Give the pilot workload and isolation/recovery evidence that would favor the leaner option.
4. Keycloak pilot versus managed OIDC. Include memory, recovery, operating labor, account ownership, and fees.
5. ConversationRelay versus a custom streaming voice stack. Compare permission handling, portability, latency, verified costs, failure routing, and integration burden.
6. Offline grant restrictions and sync ownership. Find a real field task unnecessarily blocked, or a stale-authority path that remains dangerous, then revise the policy/model.
7. Two local capabilities interpreted as local language plus speech. If two reasoning models are necessary, show the distinct tasks and measured hardware/economic benefit.
8. Complete capability catalogue: identify an omitted function, a manual path that cannot support the intended buyer, or a premature automation claim.
9. Budget and labor: replace assumptions with verified lower-cost choices that preserve outcomes; identify exclusions that change seat economics.

Suggested division by work, not claims of intrinsic model expertise: GPT keeps domain/contracts/repository and integration coherence; Grok counterdesigns topology, field failure paths, provider/hardware economics, and then reviews implementation contracts; both can rewrite any weak decision. Claude attacks the converged authority, isolation, procedure, outcome, and economics claims. Glen resolves priorities.

Round 2 return format: retained decisions; changed decisions with reasons/evidence; unresolved decisions and a discriminating experiment; concrete schema/API/code-plan deltas; cost delta; capability/status delta. No full canon rewrite and no praise-only answer. Round 3 GPT integrates; Round 4 Grok challenges the integrated build contract; Round 5 freezes versions/interfaces, writes granular instructions and actual code, and publishes what really runs plus Validation.md's remaining gaps.

The architecture is designed to let the business act inside standing authority while keeping an excellent engineer's attention on useful decisions. Its proof will be a working job and office loop under interruption, not the number of agent names or pages of generated code.


## Appendix A — complete capability traceability

This catalogue travels inside the single document for Grok. Separate CSV exports are conveniences, not required context. Floor qualifiers refer to the historical narrow prototype, not the greenfield implementation.

| ID / function | Module / current status | First functional path | Activation evidence |
|---|---|---|---|
| CAP01 · Opportunity intake | commercial · Horizon | Typed/imported request with source; actual call intake after telephony qualification | Real request retains source and missing facts |
| CAP02 · Marketplace work | marketplace · Horizon | Sourced listing import and named human handoff; entitled API later | Actual account permission and real platform receipt |
| CAP03 · Fit qualification | commercial · Horizon | Deterministic fit checklist plus sourced model advice | Unprofitable/ineligible/conflicting work is flagged |
| CAP04 · Fit-pricing and counteroffer | economics · Horizon | Cost/margin/attention calculation and authorized proposal | Cannot violate price floor or make unauthorized bid |
| CAP05 · Private quotes and accepted scope | commercial · Horizon | Versioned quote and sourced acceptance; real delivery adapter | Accepted exact terms linked to job scope revision |
| CAP06 · Change orders | authority · Horizon | Versioned scope delta invalidates affected approvals | Mid-task change opens defined interruption and hold |
| CAP07 · Protected portfolio envelopes | schedule · Floor partial / Horizon shared | Legacy tested local intervals; shared resource reservation server | Travel/prep/mentor buffers protect hard commitments |
| CAP08 · Calendar appointments | schedule · Horizon | Hub reservation; actual calendar account connector | Concurrent requests cannot double-book hard resources |
| CAP09 · Travel and dispatch | schedule · Horizon | Conservative sourced allowance; route provider optional | Timezone/access/parts/attention readiness checked |
| CAP10 · Cross-Home busy sharing | identity/schedule · Horizon | Authorized opaque intervals | Other Home customers/economics are not exposed |
| CAP11 · Preinstall survey | evidence · Horizon | Required-view checklist and original photo intake | Missing/stale/imported views remain explicit |
| CAP12 · Current Job Reality | jobs · Floor partial / Horizon projection | Legacy sourced records; new reconciled revisable projection | Conflicts and corrections preserve prior known state |
| CAP13 · Separate lifecycle tracks | jobs · Floor partial / Horizon expanded | Legacy transitions; new typed separate dimensions | Invoice/payment/delivery cannot fake field completion |
| CAP14 · Expert interface | desktop · Horizon | Native Today/dossier/tools/direct capture | Actual expert can operate without beginner wizard |
| CAP15 · Guided procedure engine | procedures · Horizon | Released bounded step engine with evidence/authority | Supported install independently inspected; honest stops |
| CAP16 · Apprenticeship graduation | competence · Horizon | Owner-reviewed scoped release and price/attention adjustment | Capability band and mentor reservation change together |
| CAP17 · Mentor escalation | procedures/voice · Horizon | Evidence/question package and real assigned reviewer | Unreachable mentor blocks steps requiring supervision |
| CAP18 · Safe interruption | jobs/procedures · Horizon | Secure-record-hold-reauthorize object and workflow | Exposed mock installation stabilized under narrow authority |
| CAP19 · Serial capture and bind | identity · Floor narrow / Horizon authenticated | Legacy observe/assign/verify/dispute/recall; migrated authenticated context | No OCR/transcription auto-verification; revision semantics preserved |
| CAP20 · Replacement/loan lineage | identity · Horizon | Temporal old/new relation with disposition | Both-direction history supports reinstall and temporary swap |
| CAP21 · Configuration backups and diff | platforms · Horizon | Real source snapshots plus semantic plan | Before/after state and recovery artifacts traceable |
| CAP22 · Cisco-familiar platform semantics | platforms · Horizon | Released exact-version pack; manual expert tools elsewhere | CX/ArubaOS-Switch/Hirschmann not treated as string substitutions |
| CAP23 · Authorized configuration write | platforms/authority · Horizon | Bounded exact approved plan with reread/test | Wrong firmware/asset/recovery capability blocks write |
| CAP24 · RS232 console | instruments · Horizon | Real pyserial session and sourced transcript | Exact USB adapter/target tested on Windows |
| CAP25 · Ethernet diagnostics | instruments · Horizon | Host link and authorized ping/IP/DNS diagnostic | Raw result/endpoints/times retained; no invented reachability |
| CAP26 · Packet capture | instruments · Horizon | Authorized tshark/Wireshark acquisition/import | Entitlement, payload classification, encryption/retention tested |
| CAP27 · Ethernet throughput | instruments · Horizon | iperf3 with real authorized second endpoint | Endpoints/profile/raw readings captured; no certification claim |
| CAP28 · Copper wiremap/length estimate | instruments · Horizon | Economy diagnostic manual capture with source photo | Instrument limits and actual result distinguish certification |
| CAP29 · Copper certification | instruments · Horizon conditional rental | Rented qualified certifier and raw report import | Contract-specific category/setup/calibration and report verified |
| CAP30 · PoE detection/load | instruments · Horizon | Manual detection records; qualified load equipment required separately | Presence never substituted for load/power-class qualification |
| CAP31 · Wi-Fi inspection/survey | instruments · Horizon | Authorized host scan and sourced survey profile | Actual locations/adapters/raw results and survey limits |
| CAP32 · Meter voltage/continuity | instruments · Horizon | Rated independent meter with manual sourced result | Operator/rating/setup/units captured; safety qualification |
| CAP33 · Scope and digital logic | instruments · Horizon extension | Qualified isolated low-voltage driver/import/manual reading | No unknown mains attachment; interface/ranges verified |
| CAP34 · RS485 and CAN | instruments · Horizon extension | Qualified isolated adapters and controlled capture | Exact bus/levels/protocol and permissions verified |
| CAP35 · RF spectrum | instruments · Horizon extension | Authentic unit with raw export/manual capture | Ranges/input protection/profile and limits verified |
| CAP36 · Thermal imaging | instruments · Horizon extension | Compatible accessory file import with provenance | Host compatibility/emissivity/context limits recorded |
| CAP37 · CCTV IP/analog | instruments · Horizon extension | Exact format tester/manual image/test capture | Actual model formats and endpoint authorization tested |
| CAP38 · Coax mapping | instruments · Horizon extension | Real mapper/source result capture | Correct cable/endpoints distinguished from RF certification |
| CAP39 · Analog telephone line | instruments · Horizon extension | Qualified rated butt-set/manual records | Line type/ratings/authority verified before connection |
| CAP40 · Basic optical readings/cleaning records | instruments · Horizon manual only | Sourced manual optical power and cleaning history | Units/wavelength/setup limits; no released novice fiber claim |
| CAP41 · Guided fiber/splicing | procedures · Halo | Fenced engineering and qualified specialist handoff | Separate tools/competence/procedure trials before release |
| CAP42 · Robot actuation | instruments/procedures · Halo | Capability contract reserved; unavailable in first product | Independent safety/authority/hardware qualification required |
| CAP43 · Custom carrier | packaging · Halo | Commodity bag/padding now | Ergonomic/rugged qualification before custom manufacturing |
| CAP44 · Stock allocations and units | materials · Floor partial / Horizon expanded | Legacy integer stock; new units/lots/owner movements | Fractional units, ownership and reservations reconcile |
| CAP45 · Purchasing and receiving | materials · Horizon | Actual manual order/receipt; entitled vendor adapter later | Spend reservation, duplicate defense, delivered quantity/cost |
| CAP46 · Returns/rental/warranty | materials/aftercare · Horizon | Sourced disposition and obligations | Returns/loan ownership/warranty history retained |
| CAP47 · Time/expenses/cost | economics · Floor partial / Horizon expanded | Legacy manual entries; typed time/cost allocation | Actual margin including owner attention reconciles |
| CAP48 · Document Desk/PDF pages | documents · Floor partial / Horizon unified | Legacy prepared HTML and PDF utility; unified versioned render/compose | Exact snapshot/page operations/render QA; no issuance claim |
| CAP49 · Customer signatures | documents · Horizon | Version-specific attributed capture; entitled e-sign integration optional | Exact document and signer context; no invented legal certification |
| CAP50 · Printing/labels | documents/instruments · Horizon | Real OS printer and standalone labeler paths | Spool result distinguished from physical paper; correct asset label |
| CAP51 · Email/fax/portal delivery | communications · Horizon | One real authorized channel; exact manual package for others | Provider receipt or sourced human submission; never fake sent |
| CAP52 · Insurance/compliance records | commercial · Horizon | Actual policy/COI intake, expiry and prerequisite checklist | Expired/missing proof blocks relevant commitment; no fabricated COI |
| CAP53 · Closeout/handover | evidence/documents · Floor partial / Horizon delivered | Legacy customer-filtered ZIP; real delivery/acceptance records | Disclosure-safe package and unresolved findings retained |
| CAP54 · Invoices/deposits/milestones | economics · Horizon | Contract-derived prepared invoice and actual issuance path | Correct authorized amounts and timing; acceptance not universal gate |
| CAP55 · Payment reconciliation | economics · Horizon | Sourced statement/payment import plus human match; feed later | Partial allocations/fees/refunds/reversals/disputes preserved |
| CAP56 · Collections and aftercare | economics/aftercare · Horizon | Standing-policy reminders and linked callback/warranty tasks | Confirmed communication and actual obligations; no guaranteed payment |
| CAP57 · SIM connectivity | device · Horizon hardware qualification | Exact WWAN/carrier/Windows configuration | Data service/coverage/sleep-resume tested; voice not inferred |
| CAP58 · Laptop incoming/outgoing calls | voice · Horizon | Hosted number and supported-browser actual audio endpoint | Real two-way calls while field tools run; sleep/network fallback |
| CAP59 · Conversational secretary | voice/AI · Horizon | Qualified Relay/text gateway or honest routing fallback | Actual intake/reservation/permission/latency/cost tests |
| CAP60 · Voice Bridge | voice · Horizon | Real conference with scoped dossier and participation modes | Listen/hot join match provider audio state and handling permissions |
| CAP61 · Consent and recording controls | voice · Horizon | Reviewed per-mode permission gate and unrecorded alternative | Refusal/new participant/withdrawal block affected modes |
| CAP62 · Local language assistance | AI · Floor adapter only / Horizon qualified | Existing Ollama request adapter; selected model evaluated | Actual target latency/quality and output provenance; no execution tools |
| CAP63 · Local dictation/OCR | AI · Horizon | Qualified whisper.cpp speech and separate extraction tools | Noisy field data evaluated; raw source and uncertainty retained |
| CAP64 · Cloud reasoning and routing | AI · Horizon | Authenticated gateway with scoped egress and atomic budget | Concurrent ceiling, outages, injection and model-quality tests |
| CAP65 · Knowledge and precedents | knowledge · Horizon | Scoped full-text/released sources first; embeddings if justified | Source provenance and permission-safe retrieval |
| CAP66 · Standing authority/exact approvals | authority · Floor local partial / Horizon authenticated | Legacy exact digest; server policies/offline signed grant | Actor/policy/scope/expiry checks cannot be bypassed |
| CAP67 · Multi-Home and sponsor isolation | identity · Horizon | OIDC grants, assignments, composite refs and RLS | Cross-Home API/cache/blob/export/webhook tests |
| CAP68 · Offline and reconnect | sync · Horizon | Authorized local capture/work plus server conflict reconciliation | Revocation limits visible; no blind outside replay |
| CAP69 · Backup/restore/cutover | recovery · Floor narrow / Horizon full | Legacy backup; new consistent manifests and inactive restore | Independent restore and old-writer/unknown-action review |
| CAP70 · Ground-up install/update/support | release · Horizon | Pinned idempotent installer, readiness report, signed release when provisioned | Clean Windows install/update rollback/tools/drivers/licenses checked |

## Appendix B — compact decision register

| ID | Status | Proposed or preserved decision | Reason | Challenge/evidence |
|---|---|---|---|---|
| D01 | Proposed | Windows edge + always-on hub + shared deterministic core | Local resilience and one shared authority | Alternative topology must preserve calls/offline/evidence/commitments |
| D02 | Proposed | Python domain and PySide6 native UI | Native hardware/offline workflow and existing Python leverage | Compare web/Tauri using actual supported hardware and voice path |
| D03 | Proposed | Separate local core; QProcess JSON-RPC; single SQLite writer | Responsive UI and controlled transaction ownership | Measure complexity versus in-process worker-thread design |
| D04 | Proposed | FastAPI modular monolith; durable worker; OIDC; Compose pilot | Small deployment without homegrown identity | Managed identity/hosting may reduce real operating labor |
| D05 | Proposed | PostgreSQL hub; local SQLite caches | Shared isolation/concurrency and local operation | Central SQLite alternative requires measured workload and isolation |
| D06 | Proposed | Typed tables + append events/audit/outbox, not full event sourcing | Queryable current state with retained history | Demonstrate a requirement that warrants full replay architecture |
| D07 | Preserved / proposed implementation | Single deterministic command authority; exact approvals; known outcomes | No model or connector bypass and no fabricated external success | Challenge canonical digest/attempt/reservation failure cases |
| D08 | Proposed | Bounded offline grants; explicit conflicts; server-owned commitments | Useful field work without impossible instant offline revocation | Find safe task blocked or stale authority allowed |
| D09 | Preserved | Safe-boundary stabilization then hold and reauthorization | Invalidation must not create physical hazard | Validate minimum safe response per released procedure |
| D10 | Proposed | Publish durable blob then metadata; consistent manifests; inactive restores | Crash recovery and no duplicate restored outside effects | Windows crash/power behavior and cutover tests |
| D11 | Preserved | Serial observation once; recall from verified binds; temporal replacement | Identity provenance and historical document integrity | Verify firmware/vendor normalization and reinstall cases |
| D12 | Proposed interpretation | Local language + local speech/extraction; cloud-normal routing | Useful two local capabilities on lean CPU kit | Clarify two reasoning models if distinct task evidence supports them |
| D13 | Proposed | Twilio browser calls + independent provider fallback; Relay candidate | Real laptop endpoint without assuming SIM-native voice | Compare verified provider costs and native voice capability |
| D14 | Preserved | Operational envelopes + fit-pricing + coupled graduation | Protect existing commitments and promised attention | Test cross-Home busy privacy, travel/timezone/overrun |
| D15 | Proposed | Instrument capability enum and explicit acquisition modes | New tools/robots without dishonest measurement claims | Validate semantic completeness and per-device ratings/interfaces |
| D16 | Preserved | Platform semantics and exact model/firmware applicability | Cisco-muscle does not justify string substitution | Actual Aruba CX lab and golden transcripts |
| D17 | Proposed | Released declarative guided steps with evidence/safe-stop gates | Guided installation is distinct engine | Try novice drift/false evidence/mentor-unavailable cases |
| D18 | Preserved | Separate tracks, movements, versioned documents, evidenced settlement | Business loop including partial payments and returns | Break contract billing timing and fee/refund allocation |
| D19 | Proposed | Domain/application/adapters/entrypoint repository boundaries | Replaceable integrations without optional authority | Grok can simplify without losing ownership/invariants |
