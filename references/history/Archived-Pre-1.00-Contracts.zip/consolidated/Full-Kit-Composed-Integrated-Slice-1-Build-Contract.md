# Full Kit Composed
## Integrated Slice 1 build contract — GPT Sol / Grok, Rounds 1–4

September 18, 2026 · prepared by GPT Sol for Glen, Grok, subsequent code generation, and Claude's adversarial review

**Build a useful local office first.** The field engineer's laptop must capture, bind, record, prepare, and back up when the SIM is in a drawer. The hub is a second deployable for shared authority, cloud assistance, and real external execution. Neither a radio nor an identity provider is required for the authorized owner's local work.

This document is the single consolidated text. It contains the retained product direction, the effective Slice 1 interfaces, Grok's fills, the necessary reconciliation decisions, functions, tests, installation conditions, and costs. Earlier round documents remain historical inputs; a generator must not guess between conflicting examples. No application code or test stub is delivered in this round. Application 0.2.0 remains unchanged. This is the build contract for the next coding round, not a declaration that the build already runs.

### 1. Product direction and boundaries

Three buyers, one engine: the premium independent engineer; the engineer developing toward independence; the service business assigning technicians. Business Home, buyer package, role, and competence remain distinct. An assigned technician does not automatically receive purchasing or banking authority. A person may serve multiple businesses without their records becoming one business.

Expert mode is quiet and direct. Guided mode eventually uses released, bounded procedures with real prerequisites, evidence gates, safe stops, and supervision. Local language and speech/OCR are two capability classes, not two reasoning brains. Cloud reasoning is normal when useful and permitted. Named employees are responsibility profiles over common services, not separate minds with separate ledgers.

Retain command authority, serial-once, operational envelopes, semantic platform packs, separate field/delivery/billing/returns/exception tracks, integer money, defensible measurement provenance, prepared versus issued, fit-pricing, and graduation coupled to capability/price/supervision. Fiber guided work, splicing, robotics, and custom carrier remain halo. No robot token or dummy adapter in the installed capability registry.

The whole composition still extends through calls, scheduling, procurement, execution, handover, billing, settled money, and aftercare. Slice 1 is its local foundation; it does not relabel a document-preparation kit as the finished commercial business.

Phone-ready still means real incoming/outgoing business calls on the SIM-connected laptop while field work continues, with hosted fallback when it sleeps or loses service. SIM data does not establish native telephone service. That qualification belongs to a later slice or a separately bounded hardware experiment. No voice-ready claim in Slice 1.

Attached reviewer instructions are proposals adjudicated under Glen's request. Grok's dominant Round 4 supplies the missing implementation detail; GPT's merge resolves contradictions rather than silently adopting incompatible rules.

### 2. Effective contract profile and merge decisions

Use the effective profiles **rpc.v0.addendum-r4**, **cmd.v0.addendum-r4**, **bind.v0.addendum-r4**, and **evidence.v0.addendum-r4** for new Slice 1 generation. Three durable contract families remain command/receipt, identity, and evidence; RPC is their transport.

The old v0 files/examples remain archived. R4 changes discriminators and evidence phases, so the effective profile is not wire-compatible with the old strict schemas. Do not label the merged payloads unchanged v0, silently accept both spellings, or validate them against the old files. Before feature generation, emit new effective-profile JSON schemas from this text and validate examples/reject cases. No application version bump is implied by changing a design contract.

| Seam | Consolidated decision |
|---|---|
| Twenty methods | Keep exactly twenty. Bounded projections and controlled read handles fill missing reads. Provision/import/activation are documented modes of the same core, with the same writer lock. |
| Track vocabulary | Keep R3 names: field planned/ready/in_progress/blocked/completed. R4's executing and blocked_open are descriptions of active physical work, not new stored enum values. Conservatively require an interruption reference for scope updates while field is in_progress or blocked. |
| Scope drift and identity | Identity verification/dispute and raw capture do not require fresh field-change authority. Record both submitted and current scope context; do not rewrite an observation's history. Scope/track changes and document snapshots have explicit freshness checks below. |
| Two-phase attach | One logical operation, explicit stage attempts, stage/publish fingerprints. Phase transitions are permitted by its state machine; ordinary operation-ID conflict rules still apply. |
| Recent receipts | Last fifty come from durable history for the selected store, across core restarts. “This process only” would defeat recovery. The client intent journal is the primary recovery mechanism; the list is a convenience. |
| Writer lock | OS-held exclusive lock, not a PID file existence check. Diagnostic PID text cannot establish ownership or justify deleting a live lock. |
| Restore identity | Allocate a new **store_instance_id/recovery_copy_id**, preserve the canonical business home_id, and start inactive. Do not silently turn restoration into a new business Home. A deliberate business fork is a separate future operation. |
| Restore access | Recovery copy may be selected explicitly for read-only inspection. Normal mutation returns RECOVERY_INACTIVE. Owner-only activation requires stopping the previous working writer and reviewing restored pending state. No automatic cutover. |
| Readiness / garbage collection | Status is local and read-only. Startup/timer/maintenance performs bounded orphan cleanup; status does not secretly mutate the ledger or perform network probes. |
| Payload unions | Actual per-kind schemas, not a permissive nullable object. Unknown fields and multiple discriminators are rejected. |
| Inbox allocation | job.create/job.update carry explicit capture_refs for raw records/evidence. Append scoped links, never copy charges or rewrite originals. Serial observations still require serial.assign and verification. |
| Resuming interrupted work | job.update track_event can append an explicit owner-sourced resolution/resume decision. Saving an interruption is not permanent deadlock, and changing scope is not automatic reauthorization. |

The restore correction preserves Grok's essential requirement—a separate inactive directory and no second live writer—while keeping Home as business ownership. Rewriting Home on every copied fact would otherwise alter provenance, break future hub identity, and require rebuilding historical hashes. Return recovery_copy_id rather than misleadingly calling it new_home_id. The two-Home test below uses a third store instance of Home A, not a fabricated third business.

### 3. Trust, local layout, and writer ownership

Slice 1 supports one trusted owner under one Windows profile. The owner can provision two Homes and explicitly switch between them. This is enforced context separation; it is not malicious-administrator isolation or multi-user technician authentication. A second human requires the later authenticated sharing implementation before receiving real data.

A minimal private owner index records Home labels, authorized store instances, recovery status, and locations. home.list returns labels/IDs/status, never filesystem locations. Desktop screen models, documents, logs, and projector-friendly readiness omit private roots. OS encryption/ACL/recovery commissioning is required before sensitive real data; uncommissioned storage reports unknown or not ready, not encrypted-by-assumption.

Layout per Home:

```text
owner-root/
  private-home-index
  home-A/
    home.lock
    ledger.sqlite
    blobs/sha256/<digest>
    staging/<token>/original
    read-cache/<token>/preview-or-original
    client-intents/
  backups/home-A/
  recovery/<new-store-instance>/   # same business Home, inactive
```

Home B has its own equivalent store and backup directory. No global cross-Home content-addressed blob directory. Source files are never interpreted as executable paths. Reject root escape, unexpected reparse/symlink targets, unsafe destination aliases, and filenames used as storage paths.

On opening a store, acquire an OS exclusive held handle on home.lock before opening writable SQLite. Windows implementation uses exclusive file sharing/locking semantics; test platforms use an equivalent nonblocking OS lock. Keep the handle for the writer's lifetime. Diagnostic content may include PID, process start, instance UUID, and time, but is not the lock. A crash releases OS ownership; the persistent file may remain. Second core on the same canonical store returns HOME_WRITER_EXISTS without reading dossier data.

Resolve path aliases so the same underlying store cannot be opened twice under different spelling. Maintenance uses the same core binary and lock primitive. Owner-index updates also have an owner-index lock and atomic publication. Provisioning, import, and recovery activation refuse conflicting writers. Never import through an undocumented second script connection while the core is running.

One desktop owns one QProcess child. Do not attach arbitrary second windows through an invented shared pipe. A second launch on a working store fails clearly. Home switching waits for an in-flight commit/publish boundary, persists unresolved client intents, invalidates unused stage/read tokens, releases the prior writer, and acquires the selected writer. Failed switching leaves a well-defined previous or no-active context, never a partially selected Home.

SQLite: supported patched runtime, WAL, FULL synchronization, foreign keys, bounded transactions, one writer queue, integrity checks. Do not infer the SQLite library from Python's version. Actual Windows/storage/power behavior remains qualification work; a process-termination pass is not a physical power-loss guarantee.

### 4. Transport, context, and twenty public methods

Default candidate is QProcess JSON-RPC 2.0, UTF-8 newline frames, stdout protocol only, stderr diagnostics, 1 MiB maximum frame. Large files travel through vetted staging, not JSON bytes. Run the two-day transport spike; an in-process single-writer queue is the fallback with identical application semantics. Do not select a more elaborate process design without evidence.

Every scoped request includes a context object: home_id, store_instance_id, session_id, session_generation. The core issues session_id on startup and increments generation on selection. Validate context before object lookup. Old sessions/generations fail HOME_CONTEXT. Ephemeral context is not part of a durable command's replay fingerprint; Home/store and semantic payload are. home.list and session.select_home are the only selection/bootstrap exceptions.

Malformed input receives a JSON-RPC validation error. Foreign context receives HOME_CONTEXT with no foreign body, location, title, timestamp, state, or revision. Never search all stores to decide whether a denied operation exists. Unknown/inaccessible operation UUIDs return the same scoped inaccessible error, so operation.get is not an existence oracle.

| # | Method | Frozen request body and bounded result |
|---|---|---|
| 1 | home.list | Empty body. Authorized Home/store labels and active/recovery status; no paths. |
| 2 | session.select_home | home_id + store_instance_id. Returns issued context; may select recovery for inspection only. |
| 3 | job.create | Command envelope + title/scope_text/capture_refs. New job UUID, aggregate/scope 1. |
| 4 | job.list | cursor null/string, limit 1–100. Scoped summaries and next_cursor. |
| 5 | job.get | job_id UUID/null, view, cursor null/string, limit 1–100. Views summary/records/observations/evidence/documents/interruptions/reservations; null job permits inbox records/observations/evidence only. |
| 6 | job.update | Command envelope + scope or track_event payload. |
| 7 | record.add | Command envelope + note/time/cost/stock_move/item_upsert payload. |
| 8 | evidence.attach | Command envelope + stage or publish payload, attempt number. |
| 9 | serial.observe | Command envelope + identity kind, raw text/null, source, nullable manufacturer/model. |
| 10 | serial.assign | Command envelope + observation_id/asset_id. Assignment once. |
| 11 | serial.verify | Command envelope + observation_id/asset_id/verification/reason. |
| 12 | serial.recall | job_id/asset_id, revision null/positive integer. Verified or unresolved result. |
| 13 | serial.dispute | Command envelope + bind_id/asset_id/reason. |
| 14 | document.prepare | Command envelope + document_type/title/body_text/asset_ids. Prepared only. |
| 15 | interruption.record | Command envelope + interruption payload. No physical automation. |
| 16 | reservation.put | Command envelope + local envelope/resource payload. |
| 17 | operation.get | operation_id. Scoped durable receipt plus attach-attempt status if applicable. |
| 18 | backup.create | Command envelope + destination_token UUID/null. Null uses the provisioned Home-specific sibling backup location. |
| 19 | backup.restore | Command envelope + archive_token/destination_token, mode inactive. Destination must be new. Returns recovery_copy_id and unchanged source_home_id. |
| 20 | system.status | active_job_id UUID/null. Local runtime/readiness and last fifty scoped durable operation summaries. |

All body properties are explicit; unknown properties are errors. Summary projection does not expand into every blob and document. Other projections paginate one named collection. All returned object references and issued read handles are scoped. No caller-defined SQL, arbitrary projections, recursive include lists, or general-purpose filesystem reader.

Evidence list rows include evidence_id, original_name, media_type, sha256, classification, and optionally a 120-second read_handle. Document rows include document_id, type, prepared_at, source job/scope revision, digest, and equivalent read_handle. A read handle is core-issued, bound to Home/store/session/generation, references only an authorized exact artifact, and expires on context change. The native helper opens only the core-published ACL-protected read-cache entry; no pasted path. Cache cleanup is background/maintenance. This is a local trusted-owner preview mechanism, not remote access authorization.

### 5. cmd.v0.addendum-r4 — envelope, revisions, receipts

Command envelope fields: schema, kind=command, operation_id, home_id, command, job_id, job_scope_revision, expected_revision, payload. The outer issued context selects the store; envelope Home must match it. No actor field, arbitrary executable command, provider success flag, or caller identity snapshot. Core attributes the trusted Windows owner; claimed names in source/verification remain claimed.

Only the thirteen mutating methods in the table use this envelope. job.create has a caller-generated new job UUID; payload title, scope_text, capture_refs (UUID array, empty when unused). Append capture can use job null for Home inbox. job_scope_revision is positive/null according to this table; expected_revision is a nonnegative integer/null. Scope freshness and target-head concurrency are separate checks.

| Command | Compared expected_revision | Scope rule / success |
|---|---|---|
| job.create | Exactly 0; job absent | Scope null; job and scope start 1. |
| job.update scope | Current job aggregate | Submitted scope equals current; increment aggregate and scope. Active/blocked field requires current interruption reference. |
| job.update track_event | Current job aggregate | Submitted scope equals current; increment aggregate; scope unchanged. |
| serial.observe | Null | Inbox null; job-tagged capture accepts stale submitted scope and records current separately. |
| serial.assign | Assignment 0 if unassigned | Current scope required. Failure never moves/reuses an existing assignment. |
| serial.verify | Current asset bind head, 0 if none | Submitted/current scope retained; drift does not block identity work. Success appends next bind revision. |
| serial.dispute | Current bind revision and active head state | Drift does not block dispute; append dispute, mark head disputed; immutable bind revision unchanged. |
| evidence.attach | Null | Inbox null; drift does not block capture. Stage attempt retains original job and context. |
| record.add | Null | Inbox null; stale job scope records submitted/current context rather than blocking raw record. |
| document.prepare | Current job aggregate | Current scope required; unresolved required pins block. Job revision is checked, not incremented merely by preparation. |
| interruption.record | Null | May record stale submitted/current scope; links actual current state. It does not block intake or perform physical actions. |
| reservation.put | Current reservation revision, 0 if new | Scope null; Home/resource/time constraints still checked. |
| backup.create / restore | Null | Scope/job null. No remote dependency. |

For an omitted or invalid context/revision type: schema error. For an authorized stale target: stable domain error such as STALE_JOB, STALE_BIND, STALE_ASSIGNMENT, or STALE_RESERVATION. No timestamps from an unrelated Home. serial.verify expected 0 when head is 1 fails STALE_BIND even if scope drift is permitted.

Receipt fields: schema, kind=receipt, operation_id, home_id, command, state, expected_revision_seen, new_revision, result_ref, error, recorded_at. States queued/executing/confirmed/failed/unknown. expected_revision_seen is the authorized target head actually checked; null for unrevisioned targets. new_revision reports the revised target or null when no revision changed. error is null unless failure; failure includes stable code and safe message. Result DTOs can include stage_attempt/read_handle/recovery_copy_id as explicitly declared method results; result_ref remains the durable result UUID.

Confirmed means the named local result is durable. It never means emailed, booked, paid, physically stabilized, or independently verified unless the corresponding sourced local record explicitly states its provenance. Unauthorized/malformed RPC produces an error rather than a foreign receipt. Valid domain failure records a receipt and audit event without partial business mutation.

Ordinary commands: canonical fingerprint covers schema profile, Home/store, command, job, submitted scope, expected revision, and payload. Same ID/same fingerprint returns its existing receipt; different fingerprint fails OPERATION_ID_CONFLICT. Persist state/event/receipt atomically. No retry with a fresh UUID to recover a response that may have been lost.

**Client intent journal:** before sending any mutating RPC, write operation UUID, semantic request, selected Home/store, and recovery state into that Home's protected client-intents directory; flush and atomically publish. If persistence fails, do not send. After response, persist acknowledgment before cleanup. On restart inspect intents for the selected store and call operation.get. A response lost after commit causes one mutation, not two. Minimize/encrypt sensitive journal content through commissioned storage and expire acknowledged entries under retention policy.

system.status recent_operations reads the last fifty receipts from that selected store across restarts, not just memory/current PID. Each summary has operation_id/command/state/recorded_at only. It supplements the journal; it cannot recover arbitrarily many forgotten IDs by itself. No false promise that a fifty-row list solves every crash.

### 6. Frozen discriminated business payloads

Generate strict oneOf schemas keyed by the stated discriminator. Every variant contains only its declared fields; forbidden sibling-variant fields are rejected. Required nullable fields are explicit null. Timestamps are offset-aware; quantities are integers; currency is USD only in Slice 1.

**record.add**, entry_kind:

- note: text, reason, source_reference nullable text.
- time: minutes positive integer, started_at/ended_at both timestamps or both null, activity, reason, source_reference nullable. If timestamps exist, validate ordering and the declared duration/rounding policy; do not invent them from minutes.
- cost: amount_cents nonnegative integer, currency USD, category, reason, source_reference nullable.
- item_upsert: item_id UUID, sku nonempty text, display_name, unit_name, reason. New item is explicit; sku unique per Home. Updates never merge item identity or rewrite historical movement snapshots.
- stock_move: item_id, quantity integer, direction receive/consume/adjust, location, unit_cost_cents nullable nonnegative integer, currency USD, reason, source_reference nullable. Receive/consume quantity is positive; adjust is signed nonzero. Receiving requires a sourced unit-cost basis or explicitly unresolved cost; unresolved does not become zero. Existing item required or ITEM_UNKNOWN. Reject negative usable stock; transactions retain movement and applicable historical cost. Integer units only.

job_id may be null for inbox notes/time/cost and Home catalog/receiving. Consumption may name a job explicitly. Saving a cost or duration is not payment issuance or employee competence evidence.

**job.update**, update_kind:

- scope: scope_text, interruption_id UUID/null, capture_refs array, reason, provenance=sourced_manual, source_reference nullable.
- track_event: track, track_state, interruption_id UUID/null, capture_refs array, reason, provenance=sourced_manual, source_reference nullable, evidence_ids array.

capture_refs is a bounded array of existing Home-inbox record/evidence UUIDs, empty when unused. Creation/update validates each reference before appending a single job association; a source already allocated to another job fails CAPTURE_ALREADY_ALLOCATED. Linking preserves original capture/job-null provenance and avoids duplicate time/cost/stock accounting. A same-state track_event may perform this explicit allocation without inventing a scope change. Serial observations are excluded: use serial.assign with the actual asset. Evidence job association is a relation, not an edit of original evidence metadata. Unknown/foreign refs return a safe scoped error, never another Home's source.

Track vocabulary:

```text
field:     planned | ready | in_progress | blocked | completed
delivery:  not_prepared | prepared | delivery_recorded | accepted | disputed
billing:   not_prepared | prepared | issued_recorded |
           partially_settled_recorded | settled_recorded | disputed
returns:   none | pending | closed
exception: none | open | held | resolved
```

Reject paid/delivered as undeclared shorthand. Manual delivery/issuance/settlement/acceptance transitions require an explicit source_reference or relevant evidence, not merely a provenance flag or clever reason string. The UI labels these as sourced/manual records; there is no connector confirmation.

Scope changes while field in_progress or blocked require interruption_id belonging to this Home/job/current scope context, with an unresolved interruption record. Missing gives FIELD_TRACK_ACTIVE; foreign/stale gives INTERRUPTION_FOREIGN or INTERRUPTION_STALE. Do not reuse an old unrelated hold to authorize new physical work. Saving new scope invalidates affected prior authority and leaves work held.

Resuming through field ready/in_progress uses interruption_id plus current-scope owner-sourced decision, reason, and source_reference/evidence. Core appends a resolution/resume event; it does not erase the interruption. Complete/resume fails when another relevant hold remains unresolved. A resume decision does not imply customer authorization when the contract requires a separate customer change acceptance. This is local recording/enforcement of declared authority, not physical control.

**interruption.record**, fields:

trigger=scope_change/tool_missing/unsafe_site/mentor_unavailable/other; step_name nullable; last_verified_state; exposed; service_impact; reversible=yes/no/unknown; irreversible=yes/no/unknown; stabilization; stabilization_done boolean; evidence_ids array; hold; responsible; state=detected/stabilizing/secured_on_hold/stabilization_failed.

Text describes conditions and changes, not only a yes/no classification. Unknown is permitted and visible. secured_on_hold requires stabilization_done true and either relevant evidence or stabilization text explicitly identifying its source (R4's SOURCED: prefix is acceptable but is not authentication). Store core observation time, submitted/current scope, and principal attribution. No emergency-exemption field. Normal work remains held until a current resolution is recorded; no automatic rollback or completion beyond changed scope.

**reservation.put**, fields:

reservation_id; starts_at; ends_at; site_timezone; state soft/hard; resources array; components_minutes containing preparation/travel/work/contingency/documentation/replenishment/aftercare/supervision. Validate positive interval, named timezone, integer minutes, envelope fit, current reservation revision, and hard-resource conflicts. No route API, calendar connector, or automatic external booking.

**document.prepare**, fields:

document_type=work_order/job_summary/closeout; title; body_text; asset_ids array. Body text is source content, not executable HTML or permission to fetch URLs. Use local shipped templates and locally permitted assets; escape content; prohibit HTTP/file-root escapes in rendering. Output immutable prepared HTML and an offline print/preview representation qualified for the chosen renderer. No hidden CDN logo/font and no signature/payment claims. Resolve serial pins inside the transaction against the current authorized bind and checked job snapshot.

### 7. bind.v0.addendum-r4 — identity facts

Retain separate immutable observation, single assignment, verified bind, and dispute facts. Required stored facts include schema/kind/Home/UUIDs, core-issued times, principal_ref, and source/provenance. New local principal attribution comes from the trusted Windows owner; claimed observer/verifier stays separate. Imported names remain legacy-claimed:<text>, not authenticated histories.

Observation: serial or asset_label; raw_value text/null; normalization trim_only.v0; nullable manufacturer/model; source kind typed/photo/imported_text/legacy_import, description, evidence_ids, observed_at, claimed_observer nullable. Photo source requires nonempty real available evidence in the same Home and applicable job/inbox context. Typed transcription of a photograph is not an OCR function. Preserve case, punctuation, internal whitespace, and leading zeroes.

Assignment: observation_id/job_id/asset_id, stored revision 1. Verification/assignment associates referenced eligible inbox evidence with the job through explicit scoped links; it never rewrites the original evidence or silently associates another job's private source. Expected assignment revision is 0. Assignment only once. Explicit new asset UUID creates the scoped asset in that transaction; no serial-similarity merge. Incorrect assignment is preserved and corrected by a new observation.

Verified bind: bind_id/observation_id/job_id/asset_id; positive revision; predecessor null only at revision 1; identity_kind; normalized_value; verification method/description/evidence IDs/claimed_verifier; reason; verification time/principal. Methods physical_label_review/source_document_review/device_inventory_review; legacy_claimed only for explicitly identified migration. Head key is Home+asset; expected 0 creates 1; correction expected 1 appends 2. A verified observation cannot be used again.

Dispute: dispute_id/bind_id/asset_id/job_id/bind_revision/reason/time/principal. Mark current head disputed without changing immutable bind content. Compare both head revision and valid transition state; a second different dispute cannot silently overwrite a prior conflict just because the numeric revision stayed unchanged.

Recall: selected Home/job must have an explicit verified asset association. Current disputed/missing/label-only/wrong-job result is status unresolved with serial null. Historical recall names the exact revision and reports current availability/dispute separately. Current preparation never silently falls back to history. Pin bind ID/revision/value in immutable documents; reject caller-supplied snapshot substitutions.

Physical replacement gets a new asset, not an identity correction. Temporal replacement/loan/reinstallation relations remain future dedicated functionality; preserve sourced legacy facts without advertising a completed graph.

### 8. evidence.v0.addendum-r4 — two-phase attach

Maximum original is **52,428,800 bytes (50 MiB)**. Reject zero/oversize before hashing; camera/import helpers enforce the same limit. First legitimate UI file selection is local trusted intake, not a remote path argument.

Stage payload:

```json
{
  "phase": "stage", "attempt": 1,
  "declared_sha256": null, "declared_length": 1234,
  "original_name": "label.jpg", "media_type": "image/jpeg",
  "origin": "camera_capture", "classification": "ordinary_job",
  "observed_at": null, "source_description": "Controlled asset label"
}
```

Origin camera_capture/file_import/legacy_import; classification ordinary_job/customer_confidential/sensitive_capture. Core persists attach intent and attempt, mints stage_token, returns queued receipt plus stage_token/stage_path/expires_at. Path is inside the selected Home's staging root and used only by native intake; never display it in document/readiness projection. Desktop writes bytes and closes/flushed the file before publishing.

Publish payload:

```json
{
  "phase": "publish", "attempt": 1,
  "stage_token": "88888888-8888-4888-8888-888888888888",
  "declared_sha256": null
}
```

Both phases use the same operation_id. Initial intent fingerprint fixes Home/store/job, metadata, declared length, and initial digest expectation. Phase, token, and attempt have separate phase fingerprints. Publish cannot change metadata or target job. If stage declared a digest, publish cannot contradict it. Core always computes the actual digest/bytes; declarations are expectations.

Token binds Home/store/session ID/generation/operation/attempt. TTL 3,600 seconds, or context change, whichever first. Use monotonic within-process expiry; tokens do not survive a core restart as publishable capabilities. Restart still preserves operation history and published results. Expired/revoked tokens fail; they never create a missing-file metadata record.

A publish attempt consumes its token whether validation succeeds or fails. A same publish request replay returns the persisted attempt result; it does not hash/mutate twice. New/different publish payload for a consumed token fails. To restage after failure/expiry, stage the same immutable intent with attempt+1 under the same operation; append history, mint a new token, never erase the failed attempt. Stage replay for an existing valid attempt returns that attempt; it does not allocate unlimited directories. Once logical attach is confirmed, no new attempt can create another evidence record. Ordinary commands retain the simpler same-ID/same-payload replay rule.

Publication: verify context/token/state; enforce size; hash and inspect actual file; validate length/type/expectation; flush; atomic same-volume publish by digest within this Home; commit available metadata/event/receipt. Metadata failure leaves an orphan; retain attempt as unknown/failed according to the actual commit outcome and reconcile before another publish. A committed receipt lost in transit is recovered by operation.get even though token is consumed. Idempotency lookup follows context authorization and precedes dead-token rejection for the identical completed request.

Available metadata includes evidence_id/Home/job nullable/blob_key/digest/length/original_name/media_type/origin/observed_at/source_description/classification/published_at/principal. blob_key is sha256/<digest> under the Home root. Original immutability remains; extraction/annotations are separate derived records.

Startup/background maintenance reconciles abandoned staging, consumed tokens, missing referenced originals, and unreferenced published blobs. Do not delete a published file merely because one failed attempt calls it orphaned: check all committed references and backup/snapshot retention. Use a documented grace period, initially 24 hours, for unreferenced published blobs. Status reports integrity faults without disguising cleanup as successful evidence capture.

### 9. Backup, restore, and import

Provision creates the Home-specific sibling backup directory. First backup requires no token ceremony: destination_token null uses it. Owner may approve another destination through maintenance/native configuration; arbitrary pasted C:\ or relative escape is rejected. A sibling same-disk copy is convenient local recovery, **not** independent disk/theft backup. Commission the encrypted external SSD and test recovery separately.

Backup pauses writes at a defined boundary, produces a consistent DB snapshot, copies every referenced original, and writes a digest manifest. Exports are not required because prepared records/snapshots are retained; report any renderer-specific artifact needed for exact reproduction. Failed/incomplete manifest is not success. Archive must exclude live locks, unneeded secrets, read-cache and abandoned staging.

Restore accepts archive/destination tokens and mode inactive only. Validate archive Home, integrity, authorization, canonical new destination, disk capacity, and absence of any existing/live store. Reject restore-over-live or merge-over-existing; allocate new store_instance_id, preserve business Home/ledger lineage/source facts, record recovery generation, and leave inactive. Source writer/store are untouched. Return recovery_copy_id/source_home_id/recovery status.

Inspect recovery by explicitly selecting its Home/store instance. Reads work; ordinary writes fail RECOVERY_INACTIVE. Owner-only maintenance activation requires prior working writer stopped, current evidence verification, pending-operation review, and explicit designation. Existing archives may contain queued/unknown actions; in Slice 1 no external executor exists. Later integration must not replay those actions without authoritative reconciliation. An inactive flag alone is not the future outside-action security boundary.

Import uses --maintenance import through the same core/lock. Source 0.2.0 is opened read-only, never initialized/upgraded in place. Inspect version/integrity; dry-run map IDs and supported fields into the selected Home; preserve claimed names/serial revision/snapshot semantics; retain source receipt/archive digest; reconcile counts and hashes; flag unsupported legacy data rather than drop it. Existing approvals are historical records, not new valid shared grants. Never migrate pending external actions into executable queues. Publish an import report; original kit remains usable for rollback, not as a second concurrent working writer.

### 10. Readiness, power, and offline behavior

Capture is never blocked by radio/hub/remote grant/provider failure in an already-unlocked trusted local session. Missing job context goes to Home inbox. Capture does not bypass a locked session, storage failure/full disk, another Home, or physical-change authorization. No secretly unencrypted anonymous emergency cache.

system.status reads local OS state, commissioned configuration, and local files only. No hub ping, route API, microphone test call, WWAN TCP probe, live license server, or remote template asset. Fields include protocol/app/SQLite version, active Home/store/session/generation, writer status, integrity result with checked_at, recent operations, and readiness. Never report cached integrity as freshly checked or substitute true for unknown.

Readiness: backup_age_hours null/observed, backup_integrity ok/failed/unknown, encrypted_volume yes/no/unknown, free_bytes, battery_percent null/observed, on_ac null/observed, wwan unknown/observed_up/observed_down, unresolved_operations count, missing_binds_on_active_job count/null, heavy_worker off/observed_active/unknown, and open interruptions. WWAN observation means local adapter state, not proven Internet or telephone reachability.

CAP71 departure readiness is horizon with real local Slice 1 reporting. Missing remote grant, pack, mentor, and telephone integration is not-included/not-applicable/unknown as appropriate; do not invent readiness. Raw capture remains available despite a warning. Owner departure override is a sourced decision, not override of a future critical procedure gate.

CAP72 power/thermal budget is horizon. Report OS battery and optional worker observations; no fake “ready for four hours” estimate or all-day guarantee. Slice 1 has no active inference worker by default. Measure target SKU capture+console, then WWAN+call, then optional inference; report thermal unknown if no qualified sensor path exists. Battery replacement/hot-swap behavior requires actual tests.

No network bridging/Internet Connection Sharing/IP forwarding in the commissioned field configuration. Later capture/calls must test interface routing so customer traffic does not acquire a route through the SIM. Interface choice alone is not an isolation sandbox; elevated tools and hostile networks require their separately qualified controls.

### 11. Modules and public functions to generate

Keep R3 module ownership; do not add a service mesh or cloud package to finish local work.

```text
fullkit/
  packages/domain/       types, invariants, tracks, identity, local office
  packages/application/  commands, queries, receipts, interruption, readiness
  apps/edge/             local core, transport, writer supervision, recovery
  apps/desktop/          Qt Today / Job / Capture / Exceptions / preview
  adapters/sqlite/
  adapters/fs_blobs/
  tests/
  migrations/local/
```

Domain imports no Qt/provider/storage SDK. Application depends on domain and ports. Adapters implement ports. Entrypoints compose. GUI and background helpers do not write SQLite directly. Models have no execution path in Slice 1.

Required public functions/services: validate_command; check_context; check_revision; canonical_fingerprint; execute_command; get_operation_receipt; scoped_query; acquire_store_writer; transaction; append_event; persist_receipt; stage_attach; publish_attach; resolve_read_handle; verify_blob; reconcile_staging; observe_identity; assign_observation; verify_bind; dispute_bind; recall_bind; prepare_document; record_time; record_cost; upsert_item; move_stock; put_reservation; record_interruption; apply_scope_change; apply_track_event/resolution; create_home_backup; verify_backup; restore_inactive; inspect_legacy; plan_import; import_legacy; reconcile_import; dispatch_rpc; select_home; build_today; get_readiness.

Today is usable, not a command dump: selected Home/job, upcoming local reservations, inbox counts/list entry, missing binds, backup/integrity warning, unresolved operations, interruption holds, and quick capture. Job shows bounded tabs and prepared artifacts. Capture supports actual typed intake and real file/photo import; no automatic OCR/ASR button. Exceptions explain failures/reconciliation and holds. Preview is an offline real artifact view. Every enabled button performs a declared function; absent integrations are absent or visibly unavailable.

### 12. First integration test and mandatory rejection suite

**Write this first, with working fixtures/assertions rather than an empty test:**

Home A and B each contain job UUID 22222222-2222-4222-8222-222222222222 and asset UUID 33333333-3333-4333-8333-333333333333. A verifies A-SERIAL; B verifies B-SERIAL. Select A and recall A-SERIAL. Select B and recall B-SERIAL. Query A's operation while B selected: HOME_CONTEXT with no A metadata. Repeat through raw RPC, not only UI. Cross-Home token/document/backup/import attempts fail. Restore A into a new inactive store instance R; A/B hashes and records unchanged. Select A/R explicitly and inspect A-SERIAL; mutation fails RECOVERY_INACTIVE. Never present R as business Home C.

Generate these meaningful cases before expanding screens:

- Context/session/generation/store mismatch; identical object IDs across Homes; same/different payload operation replay; altered actor field; unknown discriminator/nested property; malformed UUID/time; job.create expected other than 0.
- First bind 0→1, correction 1→2, stale 0 at head 1, assignment/verification once, trim-only preservation, empty photo evidence rejection, disputed/wrong-job/label recall unresolved, historical document unchanged.
- Identity/capture survives stale field scope; job scope update while in_progress/blocked rejects missing/foreign/stale interruption; current resume decision resolves only named hold; completion cannot erase other holds.
- Allocate inbox note/time/cost/evidence once to a job; no duplicate money/duration or original mutation; foreign/already-allocated refs rejected. Receive/create item and real movement; ITEM_UNKNOWN; integer units; negative stock; invalid time/cents/currency; manual settled/delivery event lacking real source rejected.
- Stage limit zero/>50 MiB; cross-Home/expired/reused/old-generation token; repeated stage; consumed-token identical publish replay; changed phase fingerprint; attempt+1 after failure; GUI dies before/after publish; core restarts; metadata failure/orphan; missing referenced file; MIME/length/digest mismatch; path/root/reparse escape.
- Client intent write failure prevents send; crash before commit, after commit before response, and after response before acknowledgment persistence; one durable mutation and recoverable receipt. Recent operations survives core restart and remains scoped; fifty-row truncation does not erase journals.
- Real OS lock rejects second core and maintenance writer; crash releases ownership without unsafe PID-file deletion; path alias duplicate; failed Home switch preserves defined context.
- Consistent complete archive, independent external restore, missing blob/incomplete manifest, inactive copy, restore-over-live/over-existing, incorrect Home archive, source unchanged import, claimed names stay claimed, unknown legacy warnings, no pending replay.
- No network access from readiness/templates; remote image/font URL input cannot fetch; no filesystem root in projector/document DTO; read-handle expiry/switch/foreign artifact; paginated inbox/job views cannot act as wildcard reads.
- Qt responsiveness with 100 staged photos and 20 commands plus resize; Home switch/restart; every enabled button; clean supported Windows install/runtime/ACL/backup readiness; unavailable battery/thermal values remain unknown.

Fault tests use disposable controlled data, not Glen's customer equipment or active ledger. Process-kill tests do not prove power-loss recovery. Windows actual GUI, disk, headset/modem, and physical procedure tests retain separate qualification status.

### 13. Ground-up install and release boundary

Before code generation, freeze supported Python/PySide6/SQLite/test dependency versions after license/security checks; do not invent pins. Installer inventories genuine Windows entitlement, runtime, storage paths, ACLs, encryption/recovery commissioning, and backup destination; provisions owner index/Homes; tests lock/store/blob/backup; reports missing optional tools. Idempotent reinstall does not overwrite business data. Build Windows packages on Windows and verify a clean machine/profile. Signing is provisioned before claiming a signed commercial release.

Qt/open-source licenses and actual packaging modules must be reviewed; no unconditional zero-license-cost claim. Ordinary user operations run without unnecessary elevation. No credentials inside the package. Maintenance sources are never executable instruction authority. Ship a Validation.md listing actual test results, target-runtime/device matrix, unresolved qualification, and release restrictions.

No ghost functions, dummy success adapters, fabricated measurements, simulated booking receipts, empty transcription implementations, or paid-status toggles presented as provider truth. Isolated fake adapters belong only in labeled tests. The requested current deliverable is text; the next coding round must implement, run, and report the declared Slice 1 functions honestly.

### 14. Out of Slice 1

Hub/API/cloud worker; managed OIDC implementation; Keycloak; PostgreSQL/RLS; sync/offline signed grants; multi-person access; shared opaque busy; browser voice console; real calls/fallback; “say Glen”; Relay; live marketplace/purchase/message/calendar execution; invoice issuance/payment automation; cloud reasoning; automatic speech/OCR; pack writes; validated guided install; robotics; guided fiber/splicing; custom carrier; stock fractions; multi-currency; WWAN network probe; template CDN; restore-over-live; simultaneous writer on one store.

Later order remains hub/auth/sync; one pack/workshop; one real office action; browser calls/fallback; full money loop. Hardware calling qualification can be scheduled earlier without polluting Slice 1. Glen's mailbox choice and C's named physical task are later inputs, not blockers for this local build contract.

### 15. Hardware, service, and engineering costs

Hardware planning allowances unchanged: **$2,320 core; $3,505 with extended instruments; $4,206 expanded with 20% contingency.** Core includes refurbished SIM-capable laptop/WWAN allowance, RAM/battery, backup SSD, basic console/network/copper tools, independent meter, hand tools/labels, headset/printer, and commodity carrier. These are prior allowances, not refreshed purchase quotations; exact SKU/carrier condition, shipping/tax/activation, certification rental and compatible accessory hosts need qualification. Buy core first; rent required certification; no GPU, robot, or custom carrier buy.

Slice 1 mandatory incremental subscriptions: **$0/month** under genuine existing Windows entitlement, compliant selected Qt/open-source distribution, and local backup. Hardware, consumables, signing/support/distribution obligations and engineering remain costs. A local same-disk archive is not a substitute for the encrypted external SSD.

No Relay or identity hosting in Slice 1. Prior illustrative first-phone-ready scenario was $70.30–120.30/month before shared hub, including a proposed $25 reasoning allowance; hub adds $33.80 and provisional managed identity $0–25. Those are incomplete scenario allowances, not a first-call invoice: the real token/routing backend, forwarding/conference/recording/speech/SMS/taxes/fees must be priced when selected. Voice basic $10.30 assumed 300 incoming and 300 outgoing laptop-browser minutes. Do not bake Relay or Keycloak into month one or silently count a voice backend as free. Current account/provider quotes are needed at activation.

**Accept Grok's revised Slice 1 estimate:**

| Work package | Hours |
|---|---:|
| Domain / RPC / storage / lock / status, including transport spike | 28–44 |
| Evidence two-phase / serial / offline documents | 28–44 |
| Local office / interruption / readiness | 18–28 |
| Qt Today / Job / Capture / Exceptions / preview / Home switch | 36–56 |
| Backup / inactive restore / 0.2.0 import | 24–40 |
| Integration / packaging / Windows smoke | 18–28 |
| **Total** | **152–240** |

At historical $75–150/hour planning rates: **$11,400–36,000 labor; $13,680–43,200 with 20% contingency.** This is not a quote. The lower-cost ugly-but-correct shell alternative reduces Qt to 24–36 hours: total 140–220. Do not cut import, writer/recovery correctness, or Home tests to meet it. New implementation complexity must update the estimate, not disappear into unpaid validation. The whole-composition estimate remains separate; $10k seat pricing remains a hypothesis requiring margin/support/willingness-to-pay evidence.

### 16. Execution and adversarial handoff

Next generation starts by emitting effective-profile schemas and the first two-Home integration test, then implements domain/application/storage/lock/receipt foundations before UI expansion. Do not count skeletons/stubs as delivered functions. Run the transport spike, keep the same application API, and freeze the choice before packaging work expands.

The release demonstration is a real offline loop: provision two local Homes; create job; capture original; typed/photo serial observation; assign/verify/recall; prepare pinned document; correct/dispute and inspect history; record time/cost/item/stock/envelope; record active-work interruption and safe sourced hold; crash/restart and recover intent/receipt; create verified backup; restore inactive and prove no live overwrite; inspect legacy import reconciliation. Report observed Windows behavior and remaining gaps.

Claude's principal attacks: make HOME_CONTEXT reveal another store's artifact; abuse job.get pagination/inbox/read handles; publish twice with one operation; recover without an intent; bypass real writer ownership; restore onto live; mutate an inactive copy; smuggle template HTTP; record false payment as provider truth; use an old interruption as current authority. Grok should receive exact schema/code/test deltas in the common directory when Glen starts that collaboration.

This consolidation completes the requested text merge. It does not execute hardware experiments, choose Glen's mailbox, supply missing physical-task facts, activate providers, or claim a commercial release.
